(() => {
  "use strict";

  const BASE = location.origin + "/studentcafe/index.cfm?do=";

  const LOGO_MARRON = "https://www.chevalier.nsw.edu.au/wp-content/themes/chev/svg/logo-maroon.svg";
  const LOGO_CREAM = "https://www.chevalier.nsw.edu.au/wp-content/themes/chev/svg/logo-white.svg";

  const ICONS = {
    home: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9a1 1 0 0 0 1 1H9a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h2.5a1 1 0 0 0 1-1v-9"/></svg>`,
    timetable: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4"/></svg>`,
    calendar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/><circle cx="8.5" cy="14.5" r="1" fill="currentColor" stroke="none"/><circle cx="12" cy="14.5" r="1" fill="currentColor" stroke="none"/><circle cx="15.5" cy="14.5" r="1" fill="currentColor" stroke="none"/></svg>`,
    bell: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9a6 6 0 0 1 12 0c0 4 1.5 5.5 2 6H4c.5-.5 2-2 2-6Z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>`,
    reports: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20V10M12 20V4M20 20v-7"/></svg>`,
    activities: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="m12 3 2.6 5.7 6.2.6-4.7 4.2 1.4 6.1L12 16.9 6.5 19.6l1.4-6.1-4.7-4.2 6.2-.6Z"/></svg>`,
    payments: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="5.5" width="19" height="13" rx="2"/><path d="M2.5 10h19"/></svg>`,
    attendance: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8 12.5 2.5 2.5L16 9.5"/></svg>`,
    details: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8.5" r="3.3"/><path d="M4.5 20c1.4-3.6 4.4-5.5 7.5-5.5s6.1 1.9 7.5 5.5"/></svg>`,
    link: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10 14 20 4M20 4h-5M20 4v5"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>`,
    logout: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>`,
    chevron: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>`
  };

  const links = [
    ["home", "Home", "studentportal.home"],
    ["timetable", "Timetable", "studentportal.timetable.main.todaysTimetable"],
    ["calendar", "Calendar", "studentportal.calendar.main.calendar"],
    ["bell", "Notices", "studentportal.calendar.main.dailynotices"],
    ["reports", "Reports", "studentportal.classes.main.myacademicreports"],
    ["activities", "Activities", "studentportal.activities.main.extraCurricular"],
    ["payments", "Events & Payments", "studentportal.activities.main.myTours"],
    ["attendance", "Attendance", "studentportal.classes.main.myattendance"],
    ["details", "My Details", "studentportal.general.main.mydetails"]
  ];

  const externalLinks = [
   ["link", "Chev Links", "https://chevaliercollege.my.canva.site/chev"],
   ["link", "Chevalier Clock", "https://chevaliercollege.my.canva.site/clock"]
  ];

  function getName() {
    const el = document.querySelector("#user-login");
    if (!el) return "Student";
    const clone = el.cloneNode(true);
    clone.querySelectorAll("*").forEach(n => n.remove());
    const value = clone.textContent.replace(/\s+/g, " ").trim();
    return value || "Student";
  }

  function currentKey() {
    const url = new URL(location.href);
    const d = url.searchParams.get("do") || "";
    if (d.includes("dailynotices")) return "Notices";
    if (d.includes("timetable")) return "Timetable";
    if (d.includes("calendar")) return "Calendar";
    if (d.includes("myacademicreports")) return "Reports";
    if (d.includes("extraCurricular")) return "Activities";
    if (d.includes("myTours")) return "Events & Payments";
    if (d.includes("myattendance")) return "Attendance";
    if (d.includes("mydetails")) return "My Details";
    return "Home";
  }

  function make(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function makeBrandMark() {
    const img = document.createElement("img");
    img.className = "orbit-logo";
    img.src = LOGO_MARRON;
    img.alt = "Chevalier College";
    img.addEventListener("error", () => {
      const fallback = make("span", "orbit-mark", "C");
      img.replaceWith(fallback);
    }, { once: true });
    return img;
  }

  function setFavicon() {
    if (document.querySelector('link[data-orbit-favicon]')) return;
    document.querySelectorAll('link[rel~="icon"]').forEach(l => l.remove());
    const link = document.createElement("link");
    link.rel = "icon";
    link.type = "image/svg+xml";
    link.href = LOGO_MARRON;
    link.setAttribute("data-orbit-favicon", "1");
    document.head.appendChild(link);
  }

  function closeModals() {
    document.querySelectorAll('.modal, [id*="notice" i]').forEach(m => {
      m.classList.remove("in", "show");
      m.style.display = "none";
    });
    document.querySelectorAll('.modal-backdrop').forEach(b => b.remove());
    document.body.classList.remove("modal-open");
  }

  function goToNotices() {
    const modalTrigger = 
      document.querySelector('.orbit-hidden [data-toggle="modal"][data-target*="notice"]') ||
      document.querySelector('.orbit-hidden [data-bs-toggle="modal"][data-bs-target*="notice"]') ||
      document.querySelector('.orbit-hidden a[href*="dailynotices"]') ||
      document.querySelector('.orbit-hidden a[id*="notice"]');

    if (modalTrigger) {
      modalTrigger.click();
      return;
    }

    const modal = document.querySelector('#noticesModal, #noticeModal, .modal[id*="notice" i]');
    if (modal) {
      closeModals();
      modal.classList.add("in", "show");
      modal.style.display = "block";
      
      modal.addEventListener("click", (e) => {
        if (e.target === modal || e.target.classList.contains("close")) {
          closeModals();
        }
      });
      return;
    }

    const candidate =
      document.getElementById("todaysnotices") ||
      document.querySelector('[id*="notice" i]') ||
      document.querySelector('[class*="notice" i]');
    if (candidate) {
      candidate.scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }

    location.href = BASE + "studentportal.calendar.main.dailynotices";
  }

  function injectCoreStyles() {
    if (document.getElementById("orbit-layout-styles")) return;
    const style = document.createElement("style");
    style.id = "orbit-layout-styles";
    style.textContent = `
      :root {
        --orbit-header-height: 60px;
        --orbit-nav-width: 0px;
      }
      @media (min-width: 1024px) {
        :root {
          --orbit-nav-width: 240px;
        }
      }
      #orbit-shell {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        right: 0 !important;
        height: var(--orbit-header-height) !important;
        z-index: 9999 !important;
      }
      #orbit-nav {
        position: fixed !important;
        top: var(--orbit-header-height) !important;
        left: 0 !important;
        height: calc(100vh - var(--orbit-header-height)) !important;
        max-height: calc(100vh - var(--orbit-header-height)) !important;
        width: var(--orbit-nav-width) !important;
        display: flex !important;
        flex-direction: column !important;
        overflow-y: auto !important;
        overflow-x: hidden !important;
        z-index: 9998 !important;
        box-sizing: border-box !important;
        -webkit-overflow-scrolling: touch;
      }
      @media (max-width: 1023px) {
        #orbit-nav {
          top: 0 !important;
          height: 100vh !important;
          max-height: 100vh !important;
          width: 280px !important;
        }
      }
      body {
        padding-top: var(--orbit-header-height) !important;
        padding-left: var(--orbit-nav-width) !important;
        box-sizing: border-box !important;
        min-height: 100vh !important;
      }
      .main-body, .main-body-content, #mainlayout {
        width: 100% !important;
        max-width: 100% !important;
        height: auto !important;
        min-height: 0 !important;
        max-height: none !important;
        overflow: visible !important;
        margin: 0 !important;
        box-sizing: border-box !important;
      }

      /* Destroy dark backdrop element entirely */
      .modal-backdrop, .modal-backdrop.fade, .modal-backdrop.in, .modal-backdrop.show {
        display: none !important;
        opacity: 0 !important;
        visibility: hidden !important;
        pointer-events: none !important;
        width: 0 !important;
        height: 0 !important;
      }

      /* Modal overlay container is transparent to clicks outside */
      .modal {
        z-index: 10000 !important;
        background: transparent !important;
        background-color: transparent !important;
      }

      /* Normal solid white card style for popup content */
      .modal-content,
      .modal-dialog {
        background: #ffffff !important;
        background-color: #ffffff !important;
        color: #1a1a1a !important;
        border-radius: 12px !important;
        border: 1px solid rgba(0, 0, 0, 0.1) !important;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1) !important;
        opacity: 1 !important;
      }

      .modal-header,
      .modal-body,
      .modal-footer {
        background: #ffffff !important;
        background-color: #ffffff !important;
        color: #1a1a1a !important;
      }
    `;
    document.head.appendChild(style);
  }

  function createOrbitUI() {
    if (document.querySelector("#orbit-shell")) return;

    const header = make("header", "orbit-header");
    header.id = "orbit-shell";

    const brand = make("a", "orbit-brand");
    brand.href = BASE + "studentportal.home";
    brand.append(makeBrandMark());

    const title = make("div", "orbit-title");
    title.innerHTML = `<strong>${currentKey()}</strong><span>${new Date().toLocaleDateString("en-AU", {
      weekday: "long", day: "numeric", month: "long"
    })}</span>`;

    const actions = make("div", "orbit-actions");
    const alertButton = make("button", "orbit-icon-btn");
    alertButton.innerHTML = ICONS.bell;
    alertButton.title = "Notices";
    alertButton.addEventListener("click", goToNotices);

    const backdrop = make("div", "orbit-backdrop");
    const closeNav = () => {
      document.body.classList.remove("orbit-nav-open");
      if (backdrop.parentNode) backdrop.remove();
    };

    backdrop.addEventListener("click", closeNav);

    const menuButton = make("button", "orbit-icon-btn mobile-only");
    menuButton.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>`;
    menuButton.addEventListener("click", () => {
      document.body.classList.add("orbit-nav-open");
      document.body.prepend(backdrop);
    });

    const oldLogout = document.querySelector("#user-logout");

    const user = make("button", "orbit-user");
    user.type = "button";
    user.innerHTML = `
      <span class="orbit-avatar">${getName().charAt(0).toUpperCase()}</span>
      <span class="orbit-user-name">${getName()}</span>
      <span class="orbit-user-chevron">${ICONS.chevron}</span>
      <div class="orbit-user-menu" role="menu">
        <a class="orbit-user-menu-item" href="${BASE}studentportal.general.main.mydetails">${ICONS.details}<span>My Details</span></a>
        <button type="button" class="orbit-user-menu-item orbit-user-logout">${ICONS.logout}<span>Log out</span></button>
      </div>
    `;
    user.addEventListener("click", (e) => {
      e.stopPropagation();
      user.classList.toggle("open");
    });
    user.querySelector(".orbit-user-logout").addEventListener("click", (e) => {
      e.stopPropagation();
      if (oldLogout) oldLogout.click();
    });
    document.addEventListener("click", () => user.classList.remove("open"));
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        user.classList.remove("open");
        closeModals();
      }
    });

    actions.append(alertButton, menuButton, user);
    header.append(brand, title, actions);

    const nav = make("aside", "orbit-nav");
    nav.id = "orbit-nav";

    const navHead = make("div", "orbit-nav-head");
    navHead.innerHTML = `<span>Student Cafe | Version 1.0.2</span><button class="orbit-close mobile-only">×</button>`;
    navHead.querySelector("button").addEventListener("click", closeNav);
    nav.append(navHead);

    const active = currentKey();
    links.forEach(([iconKey, label, target]) => {
      const a = make("a", "orbit-nav-link" + (label === active ? " active" : ""));
      a.href = BASE + target;
      a.innerHTML = `<span class="orbit-nav-icon">${ICONS[iconKey]}</span><span>${label}</span>`;
      nav.append(a);
    });

    nav.append(make("div", "orbit-nav-divider"));
    nav.append(make("div", "orbit-nav-section", "Links"));

    externalLinks.forEach(([iconKey, label, url]) => {
      const a = make("a", "orbit-nav-link");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.innerHTML = `<span class="orbit-nav-icon">${ICONS[iconKey]}</span><span>${label}</span>`;
      nav.append(a);
    });

    nav.append(make("div", "orbit-nav-divider"));

    const logout = make("button", "orbit-logout");
    logout.innerHTML = `${ICONS.logout}<span>Log out</span>`;
    logout.addEventListener("click", () => oldLogout && oldLogout.click());
    nav.append(logout);

    

    const navHead2 = make("div", "orbit-nav-head");
    navHead2.innerHTML = `<span>Bug Reports:
    aw101007@students.
    chevalier.nsw.edu.au</span><button class="orbit-close mobile-only">×</button>`;
    navHead2.querySelector("button").addEventListener("click", closeNav);
    nav.append(navHead2);

    document.body.prepend(nav);
    document.body.prepend(header);
  }

  function transformHome() {
    const sections = [
      ["timetable", "Timetable", "Your classes for today", "timetable"],
      ["calendarevents", "School Calendar", "Upcoming school events", "calendar"],
      ["todaysnotices", "Today's Notices", "Important school notices", "bell"],
      ["studentportal.classes.gadget.myacademicreports", "Academic Reports", "Your available reports", "reports"],
      ["extracurricular", "Extra Curricular", "Activities and sessions", "activities"],
      ["tours", "Events & Payments", "Upcoming events and payments", "payments"],
      ["attendance", "Attendance", "Your attendance information", "attendance"],
      ["studentportal.general.main.mydetails", "My Details", "Your student information", "details"]
    ];

    const body = document.querySelector(".main-body-content.ui-scrollspy") ||
                 document.querySelector(".main-body-content");
    if (!body || document.querySelector("#orbit-home-intro")) return;

    const intro = make("section", "orbit-intro");
    intro.id = "orbit-home-intro";
    const name = getName().split(/\s+/)[0];
    const hour = new Date().getHours();
    const greetWord = hour < 5 ? "ehh 👀" : hour < 12 ? "mornin" : hour < 18 ? "evenin" : hour < 22 ? "late night right" : "hello";
    intro.innerHTML = `
      <div>
        <span class="orbit-eyebrow">WELCOME BACK</span>
        <h1>${greetWord}, ${name}.</h1>
      </div>
      <div class="orbit-date-card">
        <strong>${new Date().toLocaleDateString("en-AU", {day:"numeric"})}</strong>
        <span>${new Date().toLocaleDateString("en-AU", {month:"short"})}</span>
      </div>
    `;

    const quick = make("section", "orbit-quick");
    quick.innerHTML = `<div class="orbit-section-label">Quick access</div><div class="orbit-quick-grid"></div>`;
    const qgrid = quick.querySelector(".orbit-quick-grid");

    sections.slice(0, 5).forEach(([id, label, desc, iconKey]) => {
      const native = document.getElementById(id);
      const card = make("button", "orbit-quick-card");
      card.innerHTML = `<span class="orbit-card-icon">${ICONS[iconKey]}</span><span><b>${label}</b><small>${desc}</small></span>`;
      card.addEventListener("click", () => {
        if (native) native.scrollIntoView({behavior:"smooth", block:"start"});
      });
      qgrid.append(card);
    });

    body.prepend(quick);
    body.prepend(intro);

    sections.forEach(([id]) => {
      const section = document.getElementById(id);
      if (section) section.classList.add("orbit-card-section");
    });
  }

  function markEmptySections() {
    document.querySelectorAll(".orbit-card-section").forEach(section => {
      const body = section.querySelector(".section-body") || section;
      const existing = body.querySelector(":scope > .orbit-empty");
      if (existing) existing.remove();
      const hasContent =
        body.querySelector("tbody tr, li, img, svg, iframe, canvas") ||
        body.textContent.replace(/\s+/g, "").length > 0;
      if (!hasContent) {
        body.appendChild(make("p", "orbit-empty", "None"));
      }
    });
  }

  function styleTables() {
    document.querySelectorAll("table").forEach(table => table.classList.add("orbit-table"));
  }

  function hideOldChrome() {
    [
      ".main-header-wrapper",
      ".main-toolbar",
      ".main-nav",
      ".left-body",
      "#toggle-header"
    ].forEach(sel => document.querySelectorAll(sel).forEach(e => e.classList.add("orbit-hidden")));
  }

  function updateLayoutVars() {
    const header = document.querySelector("#orbit-shell");
    const nav = document.querySelector("#orbit-nav");

    const headerHeight = header ? header.getBoundingClientRect().height : 60;
    document.documentElement.style.setProperty("--orbit-header-height", `${headerHeight}px`);

    if (window.innerWidth >= 1024 && nav) {
      const navWidth = nav.getBoundingClientRect().width || 240;
      document.documentElement.style.setProperty("--orbit-nav-width", `${navWidth}px`);
    } else {
      document.documentElement.style.setProperty("--orbit-nav-width", "0px");
    }
  }

  function fixPdfEmbeds() {
    document.querySelectorAll('iframe[src*=".pdf"], embed[type="application/pdf"], object[type="application/pdf"]')
      .forEach(el => {
        el.classList.add("orbit-pdf-embed");
        if (!el.dataset.orbitPdfSized) {
          el.style.setProperty("min-height", "80vh", "important");
          el.style.setProperty("width", "100%", "important");
          el.dataset.orbitPdfSized = "1";
        }
      });
  }

  function unlockScroll() {
    [document.documentElement, document.body].forEach(el => {
      el.style.removeProperty("overflow");
      el.style.removeProperty("overflow-y");
      el.style.removeProperty("overflow-x");
      el.style.removeProperty("height");
      el.style.removeProperty("max-height");
    });
    const shell = document.getElementById("mainlayout");
    if (shell) {
      shell.style.removeProperty("overflow");
      shell.style.removeProperty("height");
      shell.style.removeProperty("max-height");
    }
  }
  
const ANNOUNCEMENT_WORKER_URL =
  "https://throbbing-sunset-4c33.ryotubers.workers.dev/";

function injectAnnouncementStyles() {
  if (document.getElementById("orbit-announcement-styles")) return;

  const style = document.createElement("style");
  style.id = "orbit-announcement-styles";
  style.textContent = `
    #orbit-announcement {
      position: fixed;
      top: var(--orbit-header-height, 60px);
      left: var(--orbit-nav-width, 0px);
      width: calc(100% - var(--orbit-nav-width, 0px));
      z-index: 9997;
      box-sizing: border-box;
      padding: 12px 20px;
      font-family: inherit;
      font-size: 14px;
      line-height: 1.5;
      overflow-wrap: anywhere;
    }

    #orbit-announcement.orbit-announcement-big {
      background: #991b1b;
      color: #fff;
      border-bottom: 3px solid #7f1d1d;
      padding: 20px 24px;
      font-size: 16px;
      font-weight: 600;
      box-shadow: 0 4px 12px #0002;
    }

    #orbit-announcement.orbit-announcement-small {
      background: #fef3c7;
      color: #78350f;
      border-bottom: 1px solid #fcd34d;
    }

    #orbit-announcement[hidden] {
      display: none !important;
    }

    #orbit-announcement .orbit-announcement-label {
      display: block;
      margin-bottom: 4px;
      font-weight: 700;
      letter-spacing: .04em;
    }
  `;
  document.head.appendChild(style);
}

function getAnnouncementElement() {
  let banner = document.getElementById("orbit-announcement");

  if (!banner) {
    banner = document.createElement("div");
    banner.id = "orbit-announcement";
    banner.setAttribute("role", "status");
    banner.hidden = true;
    document.body.appendChild(banner);
  }

  return banner;
}

async function checkCloudflareAnnouncement() {
  const banner = getAnnouncementElement();

  try {
    const response = await fetch(ANNOUNCEMENT_WORKER_URL, {
      method: "GET",
      cache: "no-store"
    });

    if (!response.ok) {
      throw new Error("Announcement Worker returned an error");
    }

    const data = await response.json();

    if (data.announcement !== true) {
      banner.hidden = true;
      return;
    }

    const type = Number(data.announcetype);

    if (type !== 1 && type !== 2) {
      banner.hidden = true;
      return;
    }

    // Use textContent so message text cannot inject HTML.
    banner.replaceChildren();

    const label = document.createElement("span");
    label.className = "orbit-announcement-label";
    label.textContent = type === 1
      ? "IMPORTANT ANNOUNCEMENT"
      : "ANNOUNCEMENT";

    const message = document.createElement("div");
    message.textContent = String(data.announcemsg ?? "");

    banner.append(label, message);
    banner.classList.toggle(
      "orbit-announcement-big", type === 1
    );
    banner.classList.toggle(
      "orbit-announcement-small", type === 2
    );
    banner.hidden = false;

  } catch (error) {
    // Keep the site working if the Worker is unavailable.
    // Hide the banner rather than showing stale information.
    banner.hidden = true;
    console.warn("Could not load announcements:", error);
  }
}


  function init() {
    injectCoreStyles();
    setFavicon();
    injectAnnouncementStyles();
    checkCloudflareAnnouncement();
    createOrbitUI();
    hideOldChrome();
    styleTables();
    unlockScroll();
    updateLayoutVars();
    fixPdfEmbeds();
    if (currentKey() === "Home") transformHome();
    markEmptySections();
    if (currentKey() === "Home") pinMainRight();
    document.body.classList.add("orbit-ready");
  }

  setInterval(checkCloudflareAnnouncement, 6000);

    let userScrolled = false;
  ["wheel", "touchstart", "keydown", "mousedown"].forEach(ev =>
    window.addEventListener(ev, () => { userScrolled = true; }, { passive: true, capture: true })
  );

  function scrollMainToRight() {
    if (userScrolled) return;
    const nav = document.getElementById("orbit-nav");
    const header = document.getElementById("orbit-shell");
    const root = document.scrollingElement || document.documentElement;

    const candidates = [root, document.documentElement, document.body, ...document.querySelectorAll("body *")];
    candidates.forEach(el => {
      if (!el || (nav && nav.contains(el)) || (header && header.contains(el))) return;
      if (el.classList && el.classList.contains("orbit-quick-grid")) return; // keep quick cards starting at the left
      if (el.scrollWidth <= el.clientWidth + 5) return;
      const ox = getComputedStyle(el).overflowX;
      const isRoot = el === root || el === document.documentElement || el === document.body;
      if (isRoot || ox === "auto" || ox === "scroll") el.scrollLeft = el.scrollWidth;
    });
    window.scrollTo({ left: document.documentElement.scrollWidth, top: window.scrollY, behavior: "instant" });
  }

  function pinMainRight() {
    let tries = 0;
    const tick = () => {
      scrollMainToRight();
      if (++tries < 20 && !userScrolled) setTimeout(tick, 250); // retries for ~5s while gadgets load
    };
    tick();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, {once:true});
  } else {
    init();
  }

  window.addEventListener("resize", updateLayoutVars);
  window.addEventListener("load", () => { if (currentKey() === "Home") pinMainRight(); });

  let isFixing = false;
  const observer = new MutationObserver(() => {
    if (isFixing) return;
    isFixing = true;

    // Destroy any dynamically created black backdrops
    document.querySelectorAll('.modal-backdrop').forEach(b => b.remove());

    if (!document.querySelector("#orbit-shell")) createOrbitUI();
    hideOldChrome();
    styleTables();
    unlockScroll();
    updateLayoutVars();
    fixPdfEmbeds();
    if (currentKey() === "Home") transformHome();
    markEmptySections();

    requestAnimationFrame(() => { isFixing = false; });
  });
  observer.observe(document.documentElement, {childList:true, subtree:true});
})();