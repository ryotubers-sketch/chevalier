(() => {
  "use strict";

  const BASE = location.origin + "/studentcafe/index.cfm?do=";

  const LOGO_MARRON = "https://www.chevalier.nsw.edu.au/wp-content/themes/chev/svg/logo-maroon.svg";
  const LOGO_CREAM = "https://www.chevalier.nsw.edu.au/wp-content/themes/chev/svg/logo-white.svg";

  const ICONS = {
    home: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9a1 1 0 0 0 1 1H9a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h2.5a1 1 0 0 0 1-1v-9"/></svg>`,
    timetable: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4"/></svg>`,
    calendar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/><circle cx="8.5" cy="14.5" r="1" fill="currentColor" stroke="none"/><circle cx="12" cy="14.5" r="1" fill="currentColor" stroke="none"/><circle cx="15.5" cy="14.5" r="1" fill="currentColor" stroke="none"/></svg>`,
    bell: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9a6 6 0 0 1 12 0c0 4 1.5 5.5 2 6H4c.5-.5 2-2 2-6Z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>`,
    reports: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20V10M12 20V4M20 20v-7"/></svg>`,
    activities: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="m12 3 2.6 5.7 6.2.6-4.7 4.2 1.4 6.1L12 16.9 6.5 19.6l1.4-6.1-4.7-4.2 6.2-.6Z"/></svg>`,
    payments: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="5.5" width="19" height="13" rx="2"/><path d="M2.5 10h19"/></svg>`,
    attendance: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8 12.5 2.5 2.5L16 9.5"/></svg>`,
    details: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8.5" r="3.3"/><path d="M4.5 20c1.4-3.6 4.4-5.5 7.5-5.5s6.1 1.9 7.5 5.5"/></svg>`,
    link: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10 14 20 4M20 4h-5M20 4v5"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>`,
    logout: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>`,
    chevron: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>`
  };

  const links = [
    ["home", "Home", "studentportal.home"],
    ["timetable", "Timetable", "studentportal.timetable.main.todaysTimetable"],
    ["calendar", "Calendar", "studentportal.calendar.main.calendar"],
    ["bell", "Notices", "studentportal.calendar.main.dailynotices"],
    ["reports", "Reports", "studentportal.classes.main.myacademicreports"],
    ["activities", "Activities", "studentportal.activities.main.extraCurricular"],
    ["payments", "Events & Payments", "studentportal.activities.main.myTours"],
    ["attendance", "Attendance", "studentportal.classes.main.myattendance"],
    ["details", "My Details", "studentportal.general.main.mydetails"]
  ];

  const externalLinks = [
   ["link", "Chev Links", "https://chevaliercollege.my.canva.site/chev"],
   ["link", "Chevalier Clock", "https://chevaliercollege.my.canva.site/clock"],
   ["link", "Extension Site", "https://chevalier-collage.pages.dev"]
  ];

  function getName() {
    const el = document.querySelector("#user-login");
    if (!el) return "Student";
    const clone = el.cloneNode(true);
    clone.querySelectorAll("*").forEach(n => n.remove());
    const value = clone.textContent.replace(/\s+/g, " ").trim();
    return value || "Student";
  }

  function currentKey() {
    const url = new URL(location.href);
    const d = url.searchParams.get("do") || "";
    if (d.includes("dailynotices")) return "Notices";
    if (d.includes("timetable")) return "Timetable";
    if (d.includes("calendar")) return "Calendar";
    if (d.includes("myacademicreports")) return "Reports";
    if (d.includes("extraCurricular")) return "Activities";
    if (d.includes("myTours")) return "Events & Payments";
    if (d.includes("myattendance")) return "Attendance";
    if (d.includes("mydetails")) return "My Details";
    return "Home";
  }

  function make(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function makeBrandMark() {
    const img = document.createElement("img");
    img.className = "orbit-logo";
    img.src = LOGO_MARRON;
    img.alt = "Chevalier College";
    img.addEventListener("error", () => {
      const fallback = make("span", "orbit-mark", "C");
      img.replaceWith(fallback);
    }, { once: true });
    return img;
  }

  function setFavicon() {
    if (document.querySelector('link[data-orbit-favicon]')) return;
    document.querySelectorAll('link[rel~="icon"]').forEach(l => l.remove());
    const link = document.createElement("link");
    link.rel = "icon";
    link.type = "image/svg+xml";
    link.href = LOGO_MARRON;
    link.setAttribute("data-orbit-favicon", "1");
    document.head.appendChild(link);
  }

  function closeModals() {
    document.querySelectorAll('.modal, [id*="notice" i]').forEach(m => {
      m.classList.remove("in", "show");
      m.style.display = "none";
    });
    document.querySelectorAll('.modal-backdrop').forEach(b => b.remove());
    document.body.classList.remove("modal-open");
  }

  function goToNotices() {
    const modalTrigger = 
      document.querySelector('.orbit-hidden [data-toggle="modal"][data-target*="notice"]') ||
      document.querySelector('.orbit-hidden [data-bs-toggle="modal"][data-bs-target*="notice"]') ||
      document.querySelector('.orbit-hidden a[href*="dailynotices"]') ||
      document.querySelector('.orbit-hidden a[id*="notice"]');

    if (modalTrigger) {
      modalTrigger.click();
      return;
    }

    const modal = document.querySelector('#noticesModal, #noticeModal, .modal[id*="notice" i]');
    if (modal) {
      closeModals();
      modal.classList.add("in", "show");
      modal.style.display = "block";
      
      modal.addEventListener("click", (e) => {
        if (e.target === modal || e.target.classList.contains("close")) {
          closeModals();
        }
      });
      return;
    }

    const candidate =
      document.getElementById("todaysnotices") ||
      document.querySelector('[id*="notice" i]') ||
      document.querySelector('[class*="notice" i]');
    if (candidate) {
      candidate.scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }

    location.href = BASE + "studentportal.calendar.main.dailynotices";
  }

  function injectCoreStyles() {
    if (document.getElementById("orbit-layout-styles")) return;
    const style = document.createElement("style");
    style.id = "orbit-layout-styles";
    style.textContent = `
      :root {
        --orbit-header-height: 60px;
        --orbit-nav-width: 0px;
      }
      @media (min-width: 1024px) {
        :root {
          --orbit-nav-width: 240px;
        }
      }
      #orbit-shell {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        right: 0 !important;
        height: var(--orbit-header-height) !important;
        z-index: 9999 !important;
      }
      #orbit-nav {
        position: fixed !important;
        top: var(--orbit-header-height) !important;
        left: 0 !important;
        height: calc(100vh - var(--orbit-header-height)) !important;
        max-height: calc(100vh - var(--orbit-header-height)) !important;
        width: var(--orbit-nav-width) !important;
        display: flex !important;
        flex-direction: column !important;
        overflow-y: auto !important;
        overflow-x: hidden !important;
        z-index: 9998 !important;
        box-sizing: border-box !important;
        -webkit-overflow-scrolling: touch;
      }
      @media (max-width: 1023px) {
        #orbit-nav {
          top: 0 !important;
          height: 100vh !important;
          max-height: 100vh !important;
          width: 280px !important;
        }
      }
      body {
        padding-top: var(--orbit-header-height) !important;
        padding-left: var(--orbit-nav-width) !important;
        box-sizing: border-box !important;
        min-height: 100vh !important;
      }
      .main-body, .main-body-content, #mainlayout {
        width: 100% !important;
        max-width: 100% !important;
        height: auto !important;
        min-height: 0 !important;
        max-height: none !important;
        overflow: visible !important;
        margin: 0 !important;
        box-sizing: border-box !important;
      }

      /* Destroy dark backdrop element entirely */
      .modal-backdrop, .modal-backdrop.fade, .modal-backdrop.in, .modal-backdrop.show {
        display: none !important;
        opacity: 0 !important;
        visibility: hidden !important;
        pointer-events: none !important;
        width: 0 !important;
        height: 0 !important;
      }

      /* Modal overlay container is transparent to clicks outside */
      .modal {
        z-index: 10000 !important;
        background: transparent !important;
        background-color: transparent !important;
      }

      /* Normal solid white card style for popup content */
      .modal-content,
      .modal-dialog {
        background: #ffffff !important;
        background-color: #ffffff !important;
        color: #1a1a1a !important;
        border-radius: 12px !important;
        border: 1px solid rgba(0, 0, 0, 0.1) !important;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1) !important;
        opacity: 1 !important;
      }

      .modal-header,
      .modal-body,
      .modal-footer {
        background: #ffffff !important;
        background-color: #ffffff !important;
        color: #1a1a1a !important;
      }
      

      /* ---- taller calendar (Calendar page only) ---- */
      html.orbit-page-calendar .fc,
      html.orbit-page-calendar #calendar {
        min-height: 85vh !important;
      }
      /* FullCalendar v3/v4 */
      html.orbit-page-calendar .fc-view-container,
      html.orbit-page-calendar .fc-view,
      html.orbit-page-calendar .fc-day-grid-container {
        height: auto !important;
        max-height: none !important;
        overflow: visible !important;
      }
      html.orbit-page-calendar .fc-day-grid .fc-row { min-height: 140px !important; }
      html.orbit-page-calendar .fc-slats td { height: 3em !important; }
      /* FullCalendar v5/v6 */
      html.orbit-page-calendar .fc-daygrid-day-frame { min-height: 140px !important; }
      html.orbit-page-calendar .fc-timegrid-slot { height: 3em !important; }
      /* plain table-style calendars */
      html.orbit-page-calendar [class*="calendar" i] table td {
        height: 130px !important;
        vertical-align: top !important;
      }
    `;
    document.head.appendChild(style);
  }

  function createOrbitUI() {
    if (document.querySelector("#orbit-shell")) return;

    const header = make("header", "orbit-header");
    header.id = "orbit-shell";

    const brand = make("a", "orbit-brand");
    brand.href = BASE + "studentportal.home";
    brand.append(makeBrandMark());

    const title = make("div", "orbit-title");
    title.innerHTML = `<strong>${currentKey()}</strong><span>${new Date().toLocaleDateString("en-AU", {
      weekday: "long", day: "numeric", month: "long"
    })}</span>`;

    const actions = make("div", "orbit-actions");
    const alertButton = make("button", "orbit-icon-btn");
    alertButton.innerHTML = ICONS.bell;
    alertButton.title = "Notices";
    alertButton.addEventListener("click", goToNotices);

    const backdrop = make("div", "orbit-backdrop");
    const closeNav = () => {
      document.body.classList.remove("orbit-nav-open");
      if (backdrop.parentNode) backdrop.remove();
    };

    backdrop.addEventListener("click", closeNav);

    const menuButton = make("button", "orbit-icon-btn mobile-only");
    menuButton.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>`;
    menuButton.addEventListener("click", () => {
      document.body.classList.add("orbit-nav-open");
      document.body.prepend(backdrop);
    });

    const oldLogout = document.querySelector("#user-logout");

    // NOTE: this is a <div> (not a <button>) on purpose. A <button> can't contain
    // another <button>, so the browser was chopping the dropdown menu off after
    // "My Details".
    const user = make("div", "orbit-user");
    user.setAttribute("role", "button");
    user.tabIndex = 0;
    user.innerHTML = `
      <span class="orbit-avatar">${getName().charAt(0).toUpperCase()}</span>
      <span class="orbit-user-name">${getName()}</span>
      <span class="orbit-user-chevron">${ICONS.chevron}</span>
      <div class="orbit-user-menu" role="menu">
        <a class="orbit-user-menu-item" href="${BASE}studentportal.general.main.mydetails">${ICONS.details}<span>My Details</span></a>
        <button type="button" class="orbit-user-menu-item orbit-user-logout">${ICONS.logout}<span>Log out</span></button>
      </div>
    `;
    user.addEventListener("click", (e) => {
      e.stopPropagation();
      user.classList.toggle("open");
    });
    user.querySelector(".orbit-user-logout").addEventListener("click", (e) => {
      e.stopPropagation();
      if (oldLogout) oldLogout.click();
    });
    document.addEventListener("click", () => user.classList.remove("open"));
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        user.classList.remove("open");
        closeModals();
      }
    });

    actions.append(alertButton, menuButton, user);
    header.append(brand, title, actions);

    const nav = make("aside", "orbit-nav");
    nav.id = "orbit-nav";

    const navHead = make("div", "orbit-nav-head");
    navHead.innerHTML = `<span>Student Cafe | Version 1.2.0</span><button class="orbit-close mobile-only">×</button>`;
    navHead.querySelector("button").addEventListener("click", closeNav);
    nav.append(navHead);

    const active = currentKey();
    links.forEach(([iconKey, label, target]) => {
      const a = make("a", "orbit-nav-link" + (label === active ? " active" : ""));
      a.href = BASE + target;
      a.innerHTML = `<span class="orbit-nav-icon">${ICONS[iconKey]}</span><span>${label}</span>`;
      nav.append(a);
    });

    nav.append(make("div", "orbit-nav-divider"));
    nav.append(make("div", "orbit-nav-section", "Links"));

    externalLinks.forEach(([iconKey, label, url]) => {
      const a = make("a", "orbit-nav-link");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.innerHTML = `<span class="orbit-nav-icon">${ICONS[iconKey]}</span><span>${label}</span>`;
      nav.append(a);
    });

    nav.append(make("div", "orbit-nav-divider"));

    const logout = make("button", "orbit-logout");
    logout.innerHTML = `${ICONS.logout}<span>Log out</span>`;
    logout.addEventListener("click", () => oldLogout && oldLogout.click());
    nav.append(logout);

    

    const navHead2 = make("div", "orbit-nav-head");
    navHead2.innerHTML = `<span>Bug Reports:
    aw101007@students.
    chevalier.nsw.edu.au</span><button class="orbit-close mobile-only">×</button>`;
    navHead2.querySelector("button").addEventListener("click", closeNav);
    nav.append(navHead2);

    document.body.prepend(nav);
    document.body.prepend(header);
  }

  function transformHome() {
    const sections = [
      ["timetable", "Timetable", "Your classes for today", "timetable"],
      ["calendarevents", "School Calendar", "Upcoming school events", "calendar"],
      ["todaysnotices", "Today's Notices", "Important school notices", "bell"],
      ["studentportal.classes.gadget.myacademicreports", "Academic Reports", "Your available reports", "reports"],
      ["extracurricular", "Extra Curricular", "Activities and sessions", "activities"],
      ["tours", "Events & Payments", "Upcoming events and payments", "payments"],
      ["attendance", "Attendance", "Your attendance information", "attendance"],
      ["studentportal.general.main.mydetails", "My Details", "Your student information", "details"]
    ];

    const body = document.querySelector(".main-body-content.ui-scrollspy") ||
                 document.querySelector(".main-body-content");
    if (!body || document.querySelector("#orbit-home-intro")) return;

    const intro = make("section", "orbit-intro");
    intro.id = "orbit-home-intro";
    const name = getName().split(/\s+/)[0];
    const hour = new Date().getHours();
    const greetWord = hour < 5 ? "ehh 👀" : hour < 12 ? "mornin" : hour < 18 ? "evenin" : hour < 22 ? "late night right" : "hello";
    intro.innerHTML = `
      <div>
        <span class="orbit-eyebrow">WELCOME BACK</span>
        <h1>${greetWord}, ${name}.</h1>
      </div>
      <div class="orbit-date-card">
        <strong>${new Date().toLocaleDateString("en-AU", {day:"numeric"})}</strong>
        <span>${new Date().toLocaleDateString("en-AU", {month:"short"})}</span>
      </div>
    `;

    const quick = make("section", "orbit-quick");
    quick.innerHTML = `<div class="orbit-section-label">Quick access</div><div class="orbit-quick-grid"></div>`;
    const qgrid = quick.querySelector(".orbit-quick-grid");

    sections.slice(0, 5).forEach(([id, label, desc, iconKey]) => {
      const native = document.getElementById(id);
      const card = make("button", "orbit-quick-card");
      card.innerHTML = `<span class="orbit-card-icon">${ICONS[iconKey]}</span><span><b>${label}</b><small>${desc}</small></span>`;
      card.addEventListener("click", () => {
        if (native) native.scrollIntoView({behavior:"smooth", block:"start"});
      });
      qgrid.append(card);
    });

    body.prepend(quick);
    body.prepend(intro);

    sections.forEach(([id]) => {
      const section = document.getElementById(id);
      if (section) section.classList.add("orbit-card-section");
    });
  }

  function markEmptySections() {
    document.querySelectorAll(".orbit-card-section").forEach(section => {
      const body = section.querySelector(".section-body") || section;
      const existing = body.querySelector(":scope > .orbit-empty");
      if (existing) existing.remove();
      const hasContent =
        body.querySelector("tbody tr, li, img, svg, iframe, canvas") ||
        body.textContent.replace(/\s+/g, "").length > 0;
      if (!hasContent) {
        body.appendChild(make("p", "orbit-empty", "None"));
      }
    });
  }

  function styleTables() {
    document.querySelectorAll("table").forEach(table => table.classList.add("orbit-table"));
  }

  function hideOldChrome() {
    [
      ".main-header-wrapper",
      ".main-toolbar",
      ".main-nav",
      ".left-body",
      "#toggle-header"
    ].forEach(sel => document.querySelectorAll(sel).forEach(e => e.classList.add("orbit-hidden")));
  }

  function updateLayoutVars() {
    const header = document.querySelector("#orbit-shell");
    const nav = document.querySelector("#orbit-nav");

    const headerHeight = header ? header.getBoundingClientRect().height : 60;
    document.documentElement.style.setProperty("--orbit-header-height", `${headerHeight}px`);

    if (window.innerWidth >= 1024 && nav) {
      const navWidth = nav.getBoundingClientRect().width || 240;
      document.documentElement.style.setProperty("--orbit-nav-width", `${navWidth}px`);
    } else {
      document.documentElement.style.setProperty("--orbit-nav-width", "0px");
    }
  }

  function fixPdfEmbeds() {
    document.querySelectorAll('iframe[src*=".pdf"], embed[type="application/pdf"], object[type="application/pdf"]')
      .forEach(el => {
        el.classList.add("orbit-pdf-embed");
        if (!el.dataset.orbitPdfSized) {
          el.style.setProperty("min-height", "80vh", "important");
          el.style.setProperty("width", "100%", "important");
          el.dataset.orbitPdfSized = "1";
        }
      });
  }

  function unlockScroll() {
    [document.documentElement, document.body].forEach(el => {
      el.style.removeProperty("overflow");
      el.style.removeProperty("overflow-y");
      el.style.removeProperty("overflow-x");
      el.style.removeProperty("height");
      el.style.removeProperty("max-height");
    });
    const shell = document.getElementById("mainlayout");
    if (shell) {
      shell.style.removeProperty("overflow");
      shell.style.removeProperty("height");
      shell.style.removeProperty("max-height");
    }
  }
  
const ANNOUNCEMENT_WORKER_URL =
  "https://throbbing-sunset-4c33.ryotubers.workers.dev/";

function injectAnnouncementStyles() {
  if (document.getElementById("orbit-announcement-styles")) return;

  const style = document.createElement("style");
  style.id = "orbit-announcement-styles";
  style.textContent = `
    #orbit-announcement {
      position: fixed;
      top: var(--orbit-header-height, 60px);
      left: var(--orbit-nav-width, 0px);
      width: calc(100% - var(--orbit-nav-width, 0px));
      z-index: 9997;
      box-sizing: border-box;
      padding: 12px 20px;
      font-family: inherit;
      font-size: 14px;
      line-height: 1.5;
      overflow-wrap: anywhere;
    }

    #orbit-announcement.orbit-announcement-big {
      background: #991b1b;
      color: #fff;
      border-bottom: 3px solid #7f1d1d;
      padding: 20px 24px;
      font-size: 16px;
      font-weight: 600;
      box-shadow: 0 4px 12px #0002;
    }

    #orbit-announcement.orbit-announcement-small {
      background: #fef3c7;
      color: #78350f;
      border-bottom: 1px solid #fcd34d;
    }

    #orbit-announcement[hidden] {
      display: none !important;
    }

    #orbit-announcement .orbit-announcement-label {
      display: block;
      margin-bottom: 4px;
      font-weight: 700;
      letter-spacing: .04em;
    }
  `;
  document.head.appendChild(style);
}

function getAnnouncementElement() {
  let banner = document.getElementById("orbit-announcement");

  if (!banner) {
    banner = document.createElement("div");
    banner.id = "orbit-announcement";
    banner.setAttribute("role", "status");
    banner.hidden = true;
    document.body.appendChild(banner);
  }

  return banner;
}

let popupDismissedMsg = null;   // resets on every page refresh

function removePopup() {
  const p = document.getElementById("orbit-popup-overlay");
  if (p) p.remove();
}

function showPopup(msg) {
  if (currentKey() !== "Home") return;            // popup only on Home
  if (popupDismissedMsg === msg) return;          // closed already this page load
  if (document.getElementById("orbit-popup-overlay")) {
    const t = document.querySelector("#orbit-popup-overlay .orbit-popup-text");
    if (t && t.textContent !== msg) t.textContent = msg;
    return;
  }

  if (!document.getElementById("orbit-popup-styles")) {
    const st = document.createElement("style");
    st.id = "orbit-popup-styles";
    st.textContent = `
      #orbit-popup-overlay {
        position: fixed; inset: 0; z-index: 2147483646;
        display: flex; align-items: center; justify-content: center;
        background: rgba(0,0,0,.45); padding: 16px; box-sizing: border-box;
      }
      #orbit-popup-overlay .orbit-popup-card {
        width: min(460px, 100%); box-sizing: border-box; padding: 24px;
        background: var(--ap-panel, #fff); color: var(--ap-text, #1a1a1a);
        border: 1px solid var(--ap-border, rgba(0,0,0,.12));
        border-top: 4px solid var(--ap-accent, #8a1c4d);
        border-radius: var(--ap-radius, 14px);
        box-shadow: var(--ap-shadow, 0 24px 48px -12px rgba(0,0,0,.4));
        font-family: var(--ap-font, system-ui, sans-serif);
      }
      #orbit-popup-overlay .orbit-popup-label {
        font-size: 11px; letter-spacing: .12em; font-weight: 700;
        color: var(--ap-accent, #8a1c4d); margin-bottom: 10px;
      }
      #orbit-popup-overlay .orbit-popup-text {
        font-size: 15px; line-height: 1.6; white-space: pre-wrap; overflow-wrap: anywhere;
        max-height: 50vh; overflow-y: auto;
      }
      #orbit-popup-overlay .orbit-popup-btn {
        margin-top: 20px; padding: 9px 22px; border: 0; border-radius: 8px; cursor: pointer;
        font: inherit; font-size: 14px; font-weight: 600;
        background: var(--ap-accent, #8a1c4d); color: var(--ap-on-accent, #fff);
      }
    `;
    document.head.appendChild(st);
  }

  const overlay = document.createElement("div");
  overlay.id = "orbit-popup-overlay";
  const card = document.createElement("div");
  card.className = "orbit-popup-card";
  card.setAttribute("role", "dialog");

  const label = document.createElement("div");
  label.className = "orbit-popup-label";
  label.textContent = "ANNOUNCEMENT";

  const text = document.createElement("div");
  text.className = "orbit-popup-text";
  text.textContent = msg;              // textContent: no HTML injection

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "orbit-popup-btn";
  btn.textContent = "Got it";

  const close = () => {
    popupDismissedMsg = text.textContent;
    overlay.remove();
    document.removeEventListener("keydown", onKey, true);
  };
  const onKey = e => { if (e.key === "Escape") close(); };

  btn.addEventListener("click", close);
  overlay.addEventListener("click", e => { if (e.target === overlay) close(); });
  document.addEventListener("keydown", onKey, true);

  card.append(label, text, btn);
  overlay.append(card);
  document.documentElement.appendChild(overlay);
}

async function checkCloudflareAnnouncement() {
  const banner = getAnnouncementElement();

  try {
    const response = await fetch(ANNOUNCEMENT_WORKER_URL, {
      method: "GET",
      cache: "no-store"
    });

    if (!response.ok) {
      throw new Error("Announcement Worker returned an error");
    }

    const data = await response.json();

    if (data.announcement !== true) {
      banner.hidden = true;
      removePopup();
      return;
    }

    const type = Number(data.announcetype);

    if (type !== 1 && type !== 2 && type !== 3) {
      banner.hidden = true;
      removePopup();
      return;
    }

    const msg = String(data.announcemsg ?? "");

    // Type 3 = popup (no banner)
    if (type === 3) {
      banner.hidden = true;
      showPopup(msg);
      return;
    }

    removePopup();

    // Use textContent so message text cannot inject HTML.
    banner.replaceChildren();

    const label = document.createElement("span");
    label.className = "orbit-announcement-label";
    label.textContent = type === 1
      ? "IMPORTANT ANNOUNCEMENT"
      : "ANNOUNCEMENT";

    const message = document.createElement("div");
    message.textContent = msg;

    banner.append(label, message);
    banner.classList.toggle("orbit-announcement-big", type === 1);
    banner.classList.toggle("orbit-announcement-small", type === 2);
    banner.hidden = false;

  } catch (error) {
    banner.hidden = true;
    console.warn("Could not load announcements:", error);
  }
}

/* ======================================================================
   OFFLINE PAGE
   Paste this block inside your main (() => { ... })() wrapper, e.g. right
   after the announcement code (after checkCloudflareAnnouncement).
   ====================================================================== */
const OFFLINE_WORKER_URL = "https://broad-cell-824d.ryotubers.workers.dev/"; // <-- put your new worker URL here
const OFFLINE_TAB_URL = "https://chevalier-collage.pages.dev";
let offlineTabOpenedFor = null; // only auto-open once per message per page load

function removeOfflinePage() {
  const o = document.getElementById("orbit-offline-overlay");
  if (o) o.remove();
}

function injectOfflineStyles() {
  if (document.getElementById("orbit-offline-styles")) return;
  const st = document.createElement("style");
  st.id = "orbit-offline-styles";
  st.textContent = `
    #orbit-offline-overlay {
      position: fixed; inset: 0; z-index: 2147483645;
      display: flex; align-items: center; justify-content: center;
      background: var(--ap-bg, #f4f4f5); padding: 24px; box-sizing: border-box;
      font-family: var(--ap-font, system-ui, sans-serif);
    }
    #orbit-offline-overlay .orbit-offline-card {
      width: min(480px, 100%); box-sizing: border-box; padding: 32px; text-align: center;
      background: var(--ap-panel, #fff); color: var(--ap-text, #1a1a1a);
      border: 1px solid var(--ap-border, rgba(0,0,0,.12));
      border-top: 4px solid var(--ap-accent, #8a1c4d);
      border-radius: var(--ap-radius, 14px);
      box-shadow: var(--ap-shadow, 0 24px 48px -12px rgba(0,0,0,.4));
    }
    #orbit-offline-overlay .orbit-offline-logo { width: 64px; height: auto; margin-bottom: 12px; }
    #orbit-offline-overlay .orbit-offline-label {
      font-size: 11px; letter-spacing: .14em; font-weight: 700;
      color: var(--ap-accent, #8a1c4d); margin-bottom: 10px;
    }
    #orbit-offline-overlay .orbit-offline-text {
      font-size: 15px; line-height: 1.6; white-space: pre-wrap; overflow-wrap: anywhere;
      max-height: 50vh; overflow-y: auto;
    }
    #orbit-offline-overlay .orbit-offline-btn {
      display: inline-block; margin-top: 22px; padding: 10px 22px; border-radius: 8px;
      font: inherit; font-size: 14px; font-weight: 600; text-decoration: none; cursor: pointer;
      background: var(--ap-accent, #8a1c4d); color: var(--ap-on-accent, #fff);
    }
  `;
  document.head.appendChild(st);
}

function showOfflinePage(msg, openTab) {
  injectOfflineStyles();

  let overlay = document.getElementById("orbit-offline-overlay");
  if (overlay) {
    const t = overlay.querySelector(".orbit-offline-text");
    if (t && t.textContent !== msg) t.textContent = msg;
  } else {
    overlay = document.createElement("div");
    overlay.id = "orbit-offline-overlay";

    const card = document.createElement("div");
    card.className = "orbit-offline-card";
    card.setAttribute("role", "alertdialog");

    const logo = document.createElement("img");
    logo.className = "orbit-offline-logo";
    logo.src = LOGO_MARRON;
    logo.alt = "";
    logo.addEventListener("error", () => logo.remove(), { once: true });

    const label = document.createElement("div");
    label.className = "orbit-offline-label";
    label.textContent = "STUDENT CAFE IS OFFLINE";

    const text = document.createElement("div");
    text.className = "orbit-offline-text";
    text.textContent = msg; // textContent: no HTML injection

    card.append(logo, label, text);
    overlay.append(card);
    document.documentElement.appendChild(overlay);
  }

  // Button (always works, even if the browser blocks the auto-opened tab)
  const card = overlay.querySelector(".orbit-offline-card");
  let btn = card.querySelector(".orbit-offline-btn");
  if (openTab && !btn) {
    btn = document.createElement("a");
    btn.className = "orbit-offline-btn";
    btn.href = OFFLINE_TAB_URL;
    btn.target = "_blank";
    btn.rel = "noopener noreferrer";
    btn.textContent = "Open Extension Site";
    card.append(btn);
  } else if (!openTab && btn) {
    btn.remove();
  }

  // Try to auto-open the tab once. Browsers may block this (no user click),
  // which is why the button above exists.
  if (openTab && offlineTabOpenedFor !== msg) {
    offlineTabOpenedFor = msg;
    try { window.open(OFFLINE_TAB_URL, "_blank", "noopener,noreferrer"); } catch {}
  }
}

async function checkOffline() {
  try {
    const res = await fetch(OFFLINE_WORKER_URL, { method: "GET", cache: "no-store" });
    if (!res.ok) throw new Error("Offline Worker returned an error");
    const data = await res.json();

    if (Number(data.stats) !== 1) {
      removeOfflinePage();
      offlineTabOpenedFor = null;
      return;
    }
    showOfflinePage(String(data.msg ?? ""), data["open-tab"] === true);
  } catch (error) {
    // If the worker can't be reached, don't lock students out.
    removeOfflinePage();
    console.warn("Could not load offline status:", error);
  }
}

checkOffline();
setInterval(checkOffline, 6000);
/* ============================ end offline page ============================ */

/* ======================================================================
   TIMETABLE BANNER  (shows above the timetable on Home + Timetable tab)
   Paste this block inside your main (() => { ... })() wrapper, e.g. right
   after the OFFLINE PAGE block (or after the announcement code).
   It uses currentKey() and make(), which already exist in your script.
   ====================================================================== */
const TTBANNER_WORKER_URL = "https://floral-firefly-37aa.ryotubers.workers.dev/"; // <-- put your banner worker URL here
const TT_CACHE_KEY = "orbit-ttbanner-cache-v1";
// { text, link } when the banner should show, otherwise null.
// Starts from the last saved copy so it shows instantly after changing days/pages.
let ttBannerData = (() => {
  try {
    const c = JSON.parse(localStorage.getItem(TT_CACHE_KEY) || "null");
    return (c && typeof c.text === "string" && c.text) ? { text: c.text, link: String(c.link || "") } : null;
  } catch { return null; }
})();

function ttSafeLink(u) {
  try {
    const p = new URL(String(u || "").trim());
    return (p.protocol === "https:" || p.protocol === "http:") ? p.href : "";
  } catch { return ""; }
}

function injectTtBannerStyles() {
  if (document.getElementById("orbit-tt-banner-styles")) return;
  const st = document.createElement("style");
  st.id = "orbit-tt-banner-styles";
  st.textContent = `
    #orbit-tt-banner {
      display: flex; align-items: center; justify-content: space-between; gap: 14px;
      box-sizing: border-box; width: 100%; margin: 0 0 16px; padding: 14px 18px;
      background: color-mix(in srgb, var(--ap-accent, #8a1c4d) 12%, var(--ap-panel, #ffffff));
      color: var(--ap-text, #1a1a1a);
      border: 1px solid var(--ap-border, rgba(0,0,0,.12));
      border-left: 5px solid var(--ap-accent, #8a1c4d);
      border-radius: var(--ap-radius, 12px);
      font-size: 14px; line-height: 1.5; font-weight: 600;
      font-family: var(--ap-font, inherit);
    }
    .orbit-tt-host { flex-wrap: wrap !important; }
    #orbit-tt-banner { flex: 0 0 100%; max-width: 100%; }
    #orbit-tt-banner .orbit-tt-text { flex: 1; min-width: 0; overflow-wrap: anywhere; }
    html body a.orbit-tt-btn {
      flex-shrink: 0; display: inline-block; padding: 7px 18px; border-radius: 8px;
      font-size: 13px; font-weight: 700; text-decoration: none !important; cursor: pointer;
      background: var(--ap-accent, #8a1c4d) !important;
      color: var(--ap-on-accent, #ffffff) !important;
    }
    html body a.orbit-tt-btn:hover { filter: brightness(1.12); }
    @media (max-width: 520px) {
      #orbit-tt-banner { flex-direction: column; align-items: stretch; text-align: center; }
    }
  `;
  document.head.appendChild(st);
}

function buildTtBanner() {
  const b = document.createElement("div");
  b.id = "orbit-tt-banner";
  b.setAttribute("role", "status");
  const t = document.createElement("span");
  t.className = "orbit-tt-text";
  b.append(t);
  return b;
}

// Finds the row that holds "School Timetable 2026 Term 4 - Sat 7 Nov  < >  Today"
// by its text, so it still works when the date/term changes.
function findTtRow(scope) {
  const skip = /^(SCRIPT|STYLE|NOSCRIPT|SVG|PATH)$/i;
  const all = Array.from(scope.querySelectorAll("*"));

  // the deepest element whose text contains "School Timetable"
  const title = all.find(el => {
    if (skip.test(el.tagName) || el.closest("#orbit-tt-banner")) return false;
    if (!/School Timetable/i.test(el.textContent)) return false;
    return !Array.from(el.children).some(c => /School Timetable/i.test(c.textContent));
  });
  if (!title) return null;

  // the "Today" control (button / link / input) in the same scope
  const todayEls = Array.from(scope.querySelectorAll("a, button, input, span, div"))
    .filter(el => {
      if (el.closest("#orbit-tt-banner")) return false;
      const t = ((el.value || el.textContent) + "").trim().toLowerCase();
      return t === "today" && el.children.length === 0;
    });

  // smallest ancestor holding both the title and a "Today" control = the header row
  for (const td of todayEls) {
    let common = title;
    while (common && common !== scope && !common.contains(td)) common = common.parentElement;
    if (!common || !common.contains(td)) continue;

    if (common === scope || common.querySelector("table")) {
      // too big (includes the table): use the part that holds the title
      let child = title;
      while (child.parentElement && child.parentElement !== common) child = child.parentElement;
      return child;
    }
    return common;
  }

  // no "Today" control found: just go above the title itself
  return title;
}

// Cheap + safe to call often: only touches the page when something is out of place.
function placeTtBanner() {
  const key = currentKey();
  let banner = document.getElementById("orbit-tt-banner");

  if (!ttBannerData || (key !== "Home" && key !== "Timetable")) {
    if (banner) banner.remove();
    return;
  }

  injectTtBannerStyles();
  if (!banner) banner = buildTtBanner();

  // text (textContent: no HTML injection)
  const t = banner.querySelector(".orbit-tt-text");
  if (t.textContent !== ttBannerData.text) t.textContent = ttBannerData.text;

  // "Open" button (only if there's a valid link)
  let btn = banner.querySelector(".orbit-tt-btn");
  if (ttBannerData.link) {
    if (!btn) {
      btn = document.createElement("a");
      btn.className = "orbit-tt-btn";
      btn.target = "_blank";
      btn.rel = "noopener noreferrer";
      btn.textContent = "Open";
      banner.append(btn);
    }
    if (btn.getAttribute("href") !== ttBannerData.link) btn.setAttribute("href", ttBannerData.link);
  } else if (btn) {
    btn.remove();
  }

  // position: inside the timetable section, directly above .section-header-title
  let scope = null;
  if (key === "Home") {
    scope = document.getElementById("timetable");
  } else {
    scope = document.querySelector(".main-body-content") || document.querySelector(".main-body");
  }
  if (!scope) return;

  // already sitting right above the "School Timetable" row? nothing to do
  const next = banner.nextElementSibling;
  if (banner.isConnected && next && /School Timetable/i.test(next.textContent)) return;

  const row = findTtRow(scope);
  if (row && row.parentNode) {
    // if the row sits in a flex parent, let the banner take its own full row
    row.parentNode.classList.add("orbit-tt-host");
    if (row.previousElementSibling !== banner) row.parentNode.insertBefore(banner, row);
  } else if (key === "Timetable" && !banner.isConnected) {
    // fallback: top of the page content if the row isn't found
    // (only when the banner isn't on the page yet, so it doesn't jump around mid-redraw)
    scope.prepend(banner);
  }
  // on Home, if the row isn't there yet, wait: the next check/redraw will place it
}

async function checkTtBanner() {
  try {
    const res = await fetch(TTBANNER_WORKER_URL, { method: "GET", cache: "no-store" });
    if (!res.ok) throw new Error("Banner Worker returned an error");
    const d = await res.json();
    const text = String(d.text ?? "").trim();
    ttBannerData = (d.enabled === true && text)
      ? { text, link: ttSafeLink(d.link) }
      : null;
    try {
      if (ttBannerData) localStorage.setItem(TT_CACHE_KEY, JSON.stringify(ttBannerData));
      else localStorage.removeItem(TT_CACHE_KEY);
    } catch {}
  } catch (error) {
    ttBannerData = null; // fail quiet: no banner if the worker can't be reached
    console.warn("Could not load timetable banner:", error);
  }
  placeTtBanner();
}

// Self-healing: when the portal redraws the timetable (e.g. you change days),
// the banner gets wiped out. These put it straight back.
let ttRaf = 0;
function schedulePlaceTt() {
  if (ttRaf) return;
  ttRaf = requestAnimationFrame(() => { ttRaf = 0; placeTtBanner(); });
}
new MutationObserver(schedulePlaceTt)
  .observe(document.documentElement, { childList: true, subtree: true });
setInterval(placeTtBanner, 500); // safety net in case a redraw slips past the observer

checkTtBanner();
setInterval(checkTtBanner, 10000);

placeTtBanner(); // show the cached banner immediately

/* The two extra edits from before (adding placeTtBanner(); to init() and to the
   bottom MutationObserver) are now OPTIONAL. This block handles it by itself.
   If you already added them, leave them, they're harmless. */
/* ============================ end timetable banner ============================ */


/* ======================================================================
     APPEARANCE  (light/dark, accent colour, themes: all open to everyone)
     ====================================================================== */
  const AP_KEY = "orbit-appearance-v1";
  const AP_DEFAULT_DARK_ACCENT = "#c4577f";
  const AP_MONO = '"Cascadia Code", Consolas, "Courier New", monospace';

  // Raycast-style neutral grey
  const AP_DARK = {
    bg: "#101011", panel: "#1a1a1c", raised: "#242427", border: "#2f2f33",
    text: "#ffffff", muted: "#9a9aa1"
  };

  const AP_THEMES = {
    retro: {
      label: "Retro", dark: false,
      bg: "#e9d8b4", panel: "#f6ead0", raised: "#efdfbf", border: "#6b4423",
      text: "#3a2814", muted: "#7a6347", accent: "#d9622b",
      font: '"Courier New", Courier, monospace', radius: "0px",
      shadow: "4px 4px 0 #6b4423"
    },
    sunset: {
      label: "Sunset", dark: true,
      bg: "#1f0b2e", panel: "rgba(58,20,64,.88)", raised: "rgba(96,32,82,.75)", border: "#8a2e62",
      text: "#fff0e3", muted: "#e6aaa0", accent: "#ff7a59", radius: "14px",
      image: "linear-gradient(160deg,#2d0f45 0%,#8a2a5e 50%,#ff7a59 100%)"
    },
    hacker: {
      label: "Hacker", dark: true,
      bg: "#000000", panel: "#030b03", raised: "#071407", border: "#0b5a1c",
      text: "#39ff6a", muted: "#1fa341", accent: "#00ff41",
      font: AP_MONO, radius: "0px", glow: "0 0 8px rgba(0,255,65,.45)"
    },
    cyberpunk: {
      label: "Cyberpunk", dark: true,
      bg: "#0a0a12", panel: "#12121c", raised: "#1c1c2c", border: "#fcee0a",
      text: "#f4f4f4", muted: "#7fe7f0", accent: "#fcee0a",
      font: 'Bahnschrift, "Segoe UI", system-ui, sans-serif', radius: "0px",
      glow: "0 0 10px rgba(252,238,10,.35)"
    },
    synthwave: {
      label: "Synthwave", dark: true,
      bg: "#140a29", panel: "rgba(36,19,71,.88)", raised: "#2e1a5c", border: "#7a3cff",
      text: "#f6e9ff", muted: "#b79bdc", accent: "#ff2a95", radius: "6px",
      glow: "0 0 14px rgba(255,42,149,.45)",
      image: "linear-gradient(180deg,#140a29 0%,#2b1055 60%,#5c1a6e 100%)"
    }
  };

  const AP_SWATCHES = ["#8a1c4d", "#2563eb", "#0891b2", "#16a34a", "#d97706", "#dc2626", "#7c3aed", "#db2777"];
  const AP_VARS = ["bg", "panel", "raised", "border", "text", "muted", "accent", "on-accent", "font", "radius", "shadow", "glow", "image"];
  const AP_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a9 9 0 1 0 0 18c1.2 0 2-.8 2-1.8 0-.5-.2-.9-.5-1.2-.3-.3-.5-.7-.5-1.2 0-1 .8-1.8 1.8-1.8H17a4 4 0 0 0 4-4C21 6.7 17 3 12 3Z"/><circle cx="7.5" cy="11" r="1" fill="currentColor" stroke="none"/><circle cx="10" cy="7.5" r="1" fill="currentColor" stroke="none"/><circle cx="14.5" cy="7.5" r="1" fill="currentColor" stroke="none"/></svg>`;

  const apHasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;

  function apLoad() {
    const base = { mode: "light", accent: null, theme: "none" };
    try { return Object.assign(base, JSON.parse(localStorage.getItem(AP_KEY) || "{}")); }
    catch { return base; }
  }
  let ap = apLoad();

  // Saved in the page's localStorage AND the extension's own storage (if the
  // "storage" permission is in manifest.json), so it survives page changes.
  function apSave() {
    try { localStorage.setItem(AP_KEY, JSON.stringify(ap)); } catch {}
    if (apHasChrome) { try { chrome.storage.local.set({ [AP_KEY]: ap }); } catch {} }
  }
  if (apHasChrome) {
    try {
      chrome.storage.local.get([AP_KEY], r => {
        if (r && r[AP_KEY]) { ap = Object.assign(ap, r[AP_KEY]); apApply(); }
      });
    } catch {}
  }

  function apOn(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex || "");
    if (!m) return "#fff";
    const n = parseInt(m[1], 16);
    const lum = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
    return lum > 0.6 ? "#111111" : "#ffffff";
  }

  function apApply() {
    const root = document.documentElement;
    const theme = ap.theme !== "none" ? AP_THEMES[ap.theme] : null;
    const dark = theme ? theme.dark : ap.mode === "dark";
    const pal = theme || (dark ? AP_DARK : null);

    AP_VARS.forEach(v => root.style.removeProperty("--ap-" + v));

    let accent = null;
    if (pal) {
      accent = ap.accent || pal.accent || AP_DEFAULT_DARK_ACCENT;
      const vals = {
        bg: pal.bg, panel: pal.panel, raised: pal.raised, border: pal.border,
        text: pal.text, muted: pal.muted, font: pal.font, radius: pal.radius,
        shadow: pal.shadow || pal.glow, glow: pal.glow, image: pal.image
      };
      Object.entries(vals).forEach(([k, v]) => { if (v) root.style.setProperty("--ap-" + k, v); });
    } else if (ap.accent) {
      accent = ap.accent;
    }
    if (accent) {
      root.style.setProperty("--ap-accent", accent);
      root.style.setProperty("--ap-on-accent", apOn(accent));
    }

    root.classList.toggle("ap-pal", !!pal);
    root.classList.toggle("ap-dark", !!dark);
    root.classList.toggle("ap-theme", !!theme);
    root.classList.toggle("ap-font", !!(theme && theme.font));
    root.classList.toggle("ap-accent", !!accent);
     apSeen = new WeakSet();
     apSchedule();
  }

  function apInjectStyles() {
    if (document.getElementById("orbit-appearance-styles")) return;
    const style = document.createElement("style");
    style.id = "orbit-appearance-styles";
    style.textContent = `
      html.ap-dark { color-scheme: dark; }

      /* ---------- palette (dark + themes) ---------- */
      html.ap-pal, html.ap-pal body {
        background-color: var(--ap-bg) !important;
        background-image: var(--ap-image, none) !important;
        background-attachment: fixed !important;
        color: var(--ap-text) !important;
      }
      html.ap-font body, html.ap-font .orbit-header, html.ap-font .orbit-nav,
      html.ap-font .main-body-content, html.ap-font input, html.ap-font button,
      html.ap-font select, html.ap-font textarea { font-family: var(--ap-font) !important; }

      html.ap-pal .main-body, html.ap-pal .main-body-content, html.ap-pal #mainlayout {
        background: transparent !important; color: var(--ap-text) !important;
      }
      html.ap-pal .main-body-content :where(h1,h2,h3,h4,h5,h6,p,span,div,li,label,small,b,strong,dt,dd,legend,caption) {
        color: var(--ap-text);
      }
      html.ap-pal .orbit-header, html.ap-pal .orbit-nav {
        background: var(--ap-panel) !important; color: var(--ap-text) !important;
        border-color: var(--ap-border) !important;
      }
      html.ap-pal .orbit-nav-link, html.ap-pal .orbit-title strong, html.ap-pal .orbit-user,
      html.ap-pal .orbit-user-name, html.ap-pal .orbit-icon-btn, html.ap-pal .orbit-logout,
      html.ap-pal .orbit-user-menu-item { color: var(--ap-text) !important; }
      html.ap-pal .orbit-nav-section, html.ap-pal .orbit-nav-head, html.ap-pal .orbit-title span {
        color: var(--ap-muted) !important;
      }
      html.ap-pal .orbit-nav-link:hover, html.ap-pal .orbit-user-menu-item:hover,
      html.ap-pal .orbit-icon-btn:hover, html.ap-pal .orbit-logout:hover { background: var(--ap-raised) !important; }
      html.ap-pal .orbit-nav-divider { background: var(--ap-border) !important; }
      html.ap-pal .orbit-user-menu {
        background: var(--ap-panel) !important; border: 1px solid var(--ap-border) !important;
      }
      html.ap-pal .orbit-card-section, html.ap-pal .orbit-quick-card, html.ap-pal .orbit-intro,
      html.ap-pal .section, html.ap-pal .panel, html.ap-pal .well {
        background: var(--ap-panel) !important; color: var(--ap-text) !important;
        border-color: var(--ap-border) !important;
      }
      html.ap-pal .orbit-quick-card small, html.ap-pal .orbit-empty, html.ap-pal .text-muted {
        color: var(--ap-muted) !important;
      }
      html.ap-pal input, html.ap-pal select, html.ap-pal textarea {
        background: var(--ap-raised) !important; color: var(--ap-text) !important;
        border: 1px solid var(--ap-border) !important;
      }
      html.ap-pal .main-body-content a:not(.orbit-quick-card) { color: var(--ap-accent, #c4577f); }
      html.ap-pal .modal-content, html.ap-pal .modal-dialog,
      html.ap-pal .modal-header, html.ap-pal .modal-body, html.ap-pal .modal-footer {
        background: var(--ap-panel) !important; color: var(--ap-text) !important;
        border-color: var(--ap-border) !important;
      }

      /* ---------- theme extras ---------- */
      html.ap-theme .orbit-card-section, html.ap-theme .orbit-quick-card, html.ap-theme .orbit-intro,
      html.ap-theme .orbit-date-card, html.ap-theme .orbit-user-menu, html.ap-theme .modal-content {
        border-radius: var(--ap-radius, 8px) !important;
        box-shadow: var(--ap-shadow, none) !important;
      }
      html.ap-theme .orbit-header { border-bottom: 1px solid var(--ap-border) !important; box-shadow: var(--ap-glow, none) !important; }
      html.ap-theme .orbit-title strong, html.ap-theme .orbit-intro h1 { text-shadow: var(--ap-glow, none); }

      /* ---------- accent ---------- */
      html.ap-accent body .orbit-nav-link.active {
        background: color-mix(in srgb, var(--ap-accent) 16%, transparent) !important;
        color: var(--ap-accent) !important;
      }
      html.ap-accent body .orbit-card-icon {
        color: var(--ap-accent) !important;
        background: color-mix(in srgb, var(--ap-accent) 14%, transparent) !important;
      }

      /* welcome banner (Orbit intro) */
      html.ap-accent body .orbit-intro {
        background: linear-gradient(135deg, var(--ap-accent), color-mix(in srgb, var(--ap-accent) 65%, #000)) !important;
        border-color: transparent !important;
      }
      html.ap-accent body .orbit-intro,
      html.ap-accent body .orbit-intro * {
        color: var(--ap-on-accent) !important;
      }
      html.ap-accent body .orbit-intro .orbit-eyebrow { opacity: .8; }
      html.ap-accent body .orbit-date-card {
        background: color-mix(in srgb, var(--ap-on-accent) 14%, transparent) !important;
      }
      html.ap-accent body .orbit-date-card * { background: transparent !important; }
      html.ap-accent ::selection { background: var(--ap-accent); color: var(--ap-on-accent); }

      /* notification bell + other header icon buttons */
      html.ap-pal body .orbit-icon-btn {
        background: var(--ap-raised) !important;
        color: var(--ap-text) !important;
        border: 1px solid var(--ap-border) !important;
      }
      html.ap-pal body .orbit-icon-btn svg,
      html.ap-pal body .orbit-icon-btn svg * {
        color: var(--ap-text) !important;
        stroke: currentColor !important;
      }
      html.ap-pal body .orbit-icon-btn:hover { background: var(--ap-border) !important; }

     /* name chip at the top + its dropdown */
      html.ap-pal body .orbit-user {
        background: var(--ap-raised) !important;
        color: var(--ap-text) !important;
        border: 1px solid var(--ap-border) !important;
      }
      html.ap-pal body .orbit-user:hover,
      html.ap-pal body .orbit-user.open {
        background: var(--ap-border) !important;
      }
      html.ap-pal body .orbit-user-name,
      html.ap-pal body .orbit-user-chevron,
      html.ap-pal body .orbit-user-chevron svg,
      html.ap-pal body .orbit-user-chevron svg * {
        color: var(--ap-text) !important;
        stroke: currentColor !important;
      }
      html.ap-pal body .orbit-user-menu {
        background: var(--ap-panel) !important;
        border: 1px solid var(--ap-border) !important;
        box-shadow: 0 12px 28px rgba(0,0,0,.35) !important;
      }
      html.ap-pal body .orbit-user-menu-item,
      html.ap-pal body .orbit-user-menu-item span,
      html.ap-pal body .orbit-user-menu-item svg {
        color: var(--ap-text) !important;
        background: transparent !important;
      }
      html.ap-pal body .orbit-user-menu-item:hover { background: var(--ap-raised) !important; }
      html.ap-pal body .orbit-user:focus-visible {
        outline: 2px solid var(--ap-accent, #c4577f); outline-offset: 2px;
      }

      /* ---- information text: force theme text colour over the portal's own dark greys ---- */
            html.ap-pal body .main-body-content *:where(:not(a):not(a *):not(svg *):not(.orbit-intro):not(.orbit-intro *):not(table):not(table *)) {
        color: var(--ap-text) !important;
      }

      /* ---- white bits in the information -> accent colour (dark mode) ---- */
      html.ap-dark.ap-accent body .main-body-content :is(
        th, thead td, caption,
        .panel-heading, .card-header, .box-header, .section-header, .widget-header, .ui-widget-header,
        [style*="background:#fff"], [style*="background: #fff"],
        [style*="background-color:#fff"], [style*="background-color: #fff"],
        [style*="background:white"], [style*="background: white"],
        [style*="background-color:white"], [style*="background-color: white"],
        [style*="rgb(255, 255, 255)"]
      ) {
        background: var(--ap-accent) !important;
        border-color: var(--ap-accent) !important;
      }
      html.ap-dark.ap-accent body .main-body-content :is(
        th, thead td, caption,
        .panel-heading, .card-header, .box-header, .section-header, .widget-header, .ui-widget-header,
        [style*="background:#fff"], [style*="background: #fff"],
        [style*="background-color:#fff"], [style*="background-color: #fff"],
        [style*="background:white"], [style*="background: white"],
        [style*="background-color:white"], [style*="background-color: white"],
        [style*="rgb(255, 255, 255)"]
      ), html.ap-dark.ap-accent body .main-body-content :is(
        th, thead td, caption,
        .panel-heading, .card-header, .box-header, .section-header, .widget-header, .ui-widget-header,
        [style*="background:#fff"], [style*="background: #fff"],
        [style*="background-color:#fff"], [style*="background-color: #fff"],
        [style*="background:white"], [style*="background: white"],
        [style*="background-color:white"], [style*="background-color: white"],
        [style*="rgb(255, 255, 255)"]
      ) * {
        color: var(--ap-on-accent) !important;
      }

      /* ---- bottoms / footers of the information ---- */
      html.ap-pal body .main-body-content :is(
        .panel-footer, .card-footer, .box-footer, .section-footer, .widget-footer, .modal-footer,
        .ui-widget-content, .ui-widget-footer, .ui-state-default,
        .dataTables_wrapper, .dataTables_info, .dataTables_paginate, .dataTables_length, .dataTables_filter,
        .pagination, .pagination > li > a, .pagination > li > span, .pager, .pager li > a,
        .section-body, .gadget-footer, .more, .view-more, .viewall
      ) {
        background: var(--ap-panel) !important;
        color: var(--ap-text) !important;
        border-color: var(--ap-border) !important;
      }

      /* in dark mode with an accent: footer strips take the accent colour */
      html.ap-dark.ap-accent body .main-body-content :is(
        .panel-footer, .card-footer, .box-footer, .section-footer, .widget-footer,
        .ui-widget-footer, .gadget-footer, .dataTables_info, .dataTables_paginate
      ) {
        background: var(--ap-accent) !important;
        border-color: var(--ap-accent) !important;
      }
      html.ap-dark.ap-accent body .main-body-content :is(
        .panel-footer, .card-footer, .box-footer, .section-footer, .widget-footer,
        .ui-widget-footer, .gadget-footer, .dataTables_info, .dataTables_paginate
      ) * {
        color: var(--ap-on-accent) !important;
      }

      /* pagination buttons */
      html.ap-pal body .main-body-content .pagination > li > a:hover,
      html.ap-pal body .main-body-content .paginate_button:hover {
        background: var(--ap-raised) !important;
      }
      html.ap-pal body .main-body-content .pagination > .active > a,
      html.ap-pal body .main-body-content .paginate_button.current {
        background: var(--ap-accent, #c4577f) !important;
        color: var(--ap-on-accent, #fff) !important;
        border-color: var(--ap-accent, #c4577f) !important;
      }

      /* the page itself: no white strip under the content */
      html.ap-pal body, html.ap-pal #mainlayout, html.ap-pal .main-body,
      html.ap-pal .main-body-content, html.ap-pal .main-footer, html.ap-pal footer {
        background-color: var(--ap-bg) !important;
        color: var(--ap-text) !important;
      }

      /* ---- tabs on the portal pages ---- */
      html.ap-pal body :is(
        .nav-tabs, .nav-pills, .nav-tabs > li, .nav-tabs > li > a,
        .tab-content, .tab-pane, .tabbable, .tabs, .tab, .tab-bar,
        .ui-tabs, .ui-tabs-nav, .ui-tabs-panel, .ui-tabs .ui-tabs-nav li,
        .k-tabstrip, .k-tabstrip-items, .k-content, .k-item
      ) {
        background: var(--ap-panel) !important;
        color: var(--ap-text) !important;
        border-color: var(--ap-border) !important;
      }

      /* tab strip sits slightly raised so it reads as separate from the content */
      html.ap-pal body :is(.nav-tabs, .ui-tabs-nav, .k-tabstrip-items) {
        background: var(--ap-raised) !important;
        border-bottom: 1px solid var(--ap-border) !important;
      }
      html.ap-pal body :is(.nav-tabs > li > a, .ui-tabs .ui-tabs-nav li a, .k-tabstrip-items .k-link) {
        background: transparent !important;
        color: var(--ap-muted) !important;
        border-color: transparent !important;
      }
      html.ap-pal body :is(.nav-tabs > li > a:hover, .ui-tabs .ui-tabs-nav li a:hover) {
        background: var(--ap-border) !important;
        color: var(--ap-text) !important;
      }

      /* active tab: accent */
      html.ap-pal body :is(
        .nav-tabs > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li > a.active,
        .ui-tabs .ui-tabs-nav li.ui-tabs-active, .ui-tabs .ui-tabs-nav li.ui-tabs-active a,
        .k-tabstrip-items .k-state-active, .k-tabstrip-items .k-state-active .k-link
      ) {
        background: var(--ap-accent, #c4577f) !important;
        color: var(--ap-on-accent, #fff) !important;
        border-color: var(--ap-accent, #c4577f) !important;
      }

      /* panel under the tabs, and everything inside it */

      /* ---- JS-tagged elements (works on any page, e.g. Timetable) ---- */
      html.ap-pal body .ap-lightbg {
        background-color: var(--ap-panel) !important;
        background-image: none !important;
        border-color: var(--ap-border) !important;
      }
      html.ap-pal body .ap-darktext { color: var(--ap-text) !important; }
      html.ap-pal body .ap-darklink { color: var(--ap-accent, #c4577f) !important; }

            /* ---- dark calendar ---- */
      /* the calendar frame, grid and cells */
      html.ap-pal body :is(
        .fc, #calendar, .fc-unthemed, .fc-theme-standard, .fc-view-container, .fc-view,
        .fc-widget-content, .fc-widget-header, .fc-scrollgrid, .fc-scrollgrid-section > *,
        .fc-daygrid, .fc-daygrid-body, .fc-day-grid, .fc-day-grid-container, .fc-time-grid,
        .fc-day, .fc-bg td, .fc-slats td, .fc-daygrid-day, .fc-timegrid-slot, .fc-timegrid-col,
        .fc-list-table, .fc-list-day-cushion, .fc-list-empty
      ),
      html.ap-pal body :is(.fc, #calendar, .fc-unthemed, .fc-theme-standard) :is(td, th),
      html.ap-pal body :is([class*="calendar" i]) table :is(td, th) {
        background-color: var(--ap-panel) !important;
        border-color: var(--ap-border) !important;
        color: var(--ap-text) !important;
      }

      /* day-of-week header row */
      html.ap-pal body :is(.fc-day-header, .fc-col-header-cell, .fc-widget-header th, .fc-head td) {
        background-color: var(--ap-raised) !important;
        color: var(--ap-muted) !important;
      }

      /* days from other months are a little darker */
      html.ap-pal body :is(.fc-other-month, .fc-day-other, .fc-day-past) {
        background-color: color-mix(in srgb, var(--ap-bg) 60%, var(--ap-panel)) !important;
      }
      html.ap-pal body :is(.fc-other-month, .fc-day-other) :is(.fc-day-number, .fc-daygrid-day-number) {
        color: var(--ap-muted) !important;
      }

      /* today = accent tint */
      html.ap-pal body :is(.fc-today, .fc-day-today, td.fc-today) {
        background-color: color-mix(in srgb, var(--ap-accent, #c4577f) 22%, var(--ap-panel)) !important;
      }

      /* numbers, titles and links inside the calendar */
      html.ap-pal body :is(.fc-day-number, .fc-daygrid-day-number, .fc-day-top, .fc-col-header-cell-cushion,
        .fc-toolbar-title, .fc-toolbar h2, .fc-list-day-text, .fc-list-day-side-text, .fc-time-grid .fc-axis,
        .fc-timegrid-axis-cushion, .fc-timegrid-slot-label-cushion) {
        color: var(--ap-text) !important;
      }

      /* prev / next / today / view buttons */
      html.ap-pal body :is(.fc-button, .fc-button-primary) {
        background: var(--ap-raised) !important;
        border-color: var(--ap-border) !important;
        color: var(--ap-text) !important;
        text-shadow: none !important;
        box-shadow: none !important;
      }
      html.ap-pal body :is(.fc-button:hover, .fc-button-primary:hover) { background: var(--ap-border) !important; }
      html.ap-pal body :is(.fc-button-active, .fc-button.fc-state-active, .fc-button-primary:not(:disabled).fc-button-active) {
        background: var(--ap-accent, #c4577f) !important;
        border-color: var(--ap-accent, #c4577f) !important;
        color: var(--ap-on-accent, #fff) !important;
      }

      /* ---------- THEMED TABLES ---------- */

      table.orbit-table,
        .main-body-content table {
        width: 100%;
         border-collapse: separate !important;
        border-spacing: 0;
        background: var(--ap-panel, #ffffff) !important;
        color: var(--ap-text, #222222) !important;
        border: 1px solid var(--ap-border, #dddddd) !important;
        border-radius: var(--ap-radius, 12px);
       overflow: hidden;
        box-shadow: var(--ap-shadow, 0 3px 12px rgba(0,0,0,0.06));
      }

      /* Table headings */
      table.orbit-table th,
       .main-body-content table th {
        background: var(--ap-accent, #520f2e) !important;
        color: var(--ap-on-accent, #ffffff) !important;
       padding: 13px 15px !important;
       font-weight: 700 !important;
       text-align: left;
       border-bottom: 1px solid var(--ap-border, #dddddd) !important;
      }

      /* Table cells */
      table.orbit-table td,
      .main-body-content table td {
          background: var(--ap-panel, #ffffff) !important;
          color: var(--ap-text, #222222) !important;
          padding: 12px 15px !important;
         border-bottom: 1px solid var(--ap-border, #dddddd) !important;
      }

      /* Alternating rows */
      table.orbit-table tbody tr:nth-child(even) td,
      .main-body-content table tbody tr:nth-child(even) td {
          background: var(--ap-raised, #f5f5f5) !important;
      }

      /* Hover effect */
      table.orbit-table tbody tr:hover td,
      .main-body-content table tbody tr:hover td {
         background: color-mix(
         in srgb,
         var(--ap-accent, #520f2e) 9%,
          var(--ap-panel, #ffffff)
      ) !important;
      }

      /* Remove final row border */
      table.orbit-table tr:last-child td,
      .main-body-content table tr:last-child td {
          border-bottom: none !important;
      }

      /* Table links */
        able.orbit-table a,
      .main-body-content table a {
         color: var(--ap-accent, #520f2e) !important;
      }


      /* ---------- appearance popup ---------- */
      #ap-overlay .ap-card {
        background: var(--ap-panel, #fff); color: var(--ap-text, #1a1a1a);
        border: 1px solid var(--ap-border, rgba(0,0,0,.12)); border-radius: var(--ap-radius, 14px);
        box-shadow: var(--ap-shadow, 0 24px 48px -12px rgba(0,0,0,.4));
        font-family: var(--ap-font, system-ui, sans-serif);
      }
      #ap-overlay .ap-head {
        display: flex; justify-content: space-between; align-items: center;
        padding: 16px 20px; border-bottom: 1px solid var(--ap-border, rgba(0,0,0,.1)); font-size: 16px;
      }
      #ap-overlay .ap-x {
        background: none; border: 0; font-size: 24px; line-height: 1; cursor: pointer; color: var(--ap-muted, #666);
      }
      #ap-overlay .ap-body { padding: 8px 20px 20px; }
      #ap-overlay .ap-sec { margin-top: 16px; }
      #ap-overlay .ap-label {
        font-size: 11px; letter-spacing: .12em; text-transform: uppercase;
        color: var(--ap-muted, #777); margin-bottom: 8px; font-weight: 600;
      }
      #ap-overlay .ap-note { font-size: 12px; color: var(--ap-muted, #777); margin-bottom: 8px; }
      #ap-overlay .ap-seg { display: inline-flex; border: 1px solid var(--ap-border, rgba(0,0,0,.15)); border-radius: 8px; overflow: hidden; }
      #ap-overlay .ap-seg button {
        padding: 8px 22px; border: 0; cursor: pointer; font: inherit; font-size: 13px;
        background: transparent; color: var(--ap-text, #222);
      }
      #ap-overlay .ap-seg button.on { background: var(--ap-accent, #8a1c4d); color: var(--ap-on-accent, #fff); }
      #ap-overlay .ap-swatches { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; }
      #ap-overlay .ap-sw {
        width: 30px; height: 30px; border-radius: 50%; cursor: pointer; padding: 0;
        border: 2px solid transparent; outline: 1px solid var(--ap-border, rgba(0,0,0,.2)); outline-offset: 1px;
      }
      #ap-overlay .ap-sw.on { border-color: var(--ap-panel, #fff); outline: 2px solid var(--ap-text, #222); }
      #ap-overlay .ap-sw.reset { background: linear-gradient(135deg,#fff 45%,#d33 46%,#d33 54%,#fff 55%); }
      /* custom colour picker: round, matches the swatches */
      #ap-overlay .ap-custom {
        position: relative; display: inline-block; width: 30px; height: 30px; border-radius: 50%;
        cursor: pointer; padding: 2px; box-sizing: border-box;
        background: conic-gradient(#f43f5e, #f59e0b, #84cc16, #06b6d4, #6366f1, #d946ef, #f43f5e);
        outline: 1px solid var(--ap-border, rgba(0,0,0,.2)); outline-offset: 1px;
      }
      #ap-overlay .ap-custom.on { outline: 2px solid var(--ap-text, #222); }
      #ap-overlay .ap-custom input[type="color"] {
        -webkit-appearance: none; appearance: none;
        width: 100% !important; height: 100% !important; padding: 0 !important; margin: 0;
        border: 2px solid var(--ap-panel, #fff) !important; border-radius: 50% !important;
        background: none !important; cursor: pointer; display: block;
      }
      #ap-overlay .ap-custom input[type="color"]::-webkit-color-swatch-wrapper { padding: 0; }
      #ap-overlay .ap-custom input[type="color"]::-webkit-color-swatch { border: 0; border-radius: 50%; }
      #ap-overlay .ap-custom input[type="color"]::-moz-color-swatch { border: 0; border-radius: 50%; }
      #ap-overlay .ap-themes { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; }
      #ap-overlay .ap-theme {
        text-align: left; padding: 10px; cursor: pointer; font: inherit; font-size: 13px;
        background: var(--ap-raised, #f4f4f5); color: var(--ap-text, #222);
        border: 2px solid var(--ap-border, rgba(0,0,0,.12)); border-radius: 10px;
      }
      #ap-overlay .ap-theme.on { border-color: var(--ap-accent, #8a1c4d); }
      #ap-overlay .ap-theme small { display: block; font-size: 11px; color: var(--ap-muted, #777); }
      #ap-overlay .ap-prev {
        display: flex; gap: 6px; align-items: flex-end; height: 44px; padding: 6px;
        border: 1px solid; border-radius: 6px; margin-bottom: 8px; box-sizing: border-box;
      }
      #ap-overlay .ap-prev i { display: block; width: 18px; height: 18px; border-radius: 4px; }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function apRender() {
    const overlay = document.getElementById("ap-overlay");
    if (!overlay) return;
    const card = overlay.querySelector(".ap-card");
    const keepScroll = card ? card.scrollTop : 0;
    const body = overlay.querySelector(".ap-body");
    const themeActive = ap.theme !== "none" && AP_THEMES[ap.theme];

    const swatches = AP_SWATCHES.map(c =>
      `<button type="button" class="ap-sw${ap.accent === c ? " on" : ""}" data-ap-accent="${c}" style="background:${c}" aria-label="Accent ${c}"></button>`
    ).join("");

    const themeCards = [
      `<button type="button" class="ap-theme${ap.theme === "none" ? " on" : ""}" data-ap-theme="none">
         <span class="ap-prev" style="background:#f4f4f5;border-color:#ccc"><i style="background:#8a1c4d"></i><i style="background:#999"></i></span><b>None</b><small>Standard look</small></button>`
    ].concat(Object.entries(AP_THEMES).map(([key, t]) => {
      const bg = t.image || t.bg;
      return `<button type="button" class="ap-theme${ap.theme === key ? " on" : ""}" data-ap-theme="${key}">
        <span class="ap-prev" style="background:${bg};border-color:${t.border}"><i style="background:${t.accent}"></i><i style="background:${t.text}"></i></span>
        <b>${t.label}</b></button>`;
    })).join("");

    body.innerHTML = `
      <div style="
      padding: 12px 14px;
      margin-bottom: 16px;
        border-radius: 10px;
      background: #fff7e6;
      border: 1px solid #f0c36d;
      color: #805500;
      font-size: 12px;
       line-height: 1.5;
      ">
       <strong>⚠️ Experimental Feature</strong>
      </div>
      <div class="ap-sec">
        <div class="ap-label">Mode</div>
        <div class="ap-seg">
          <button type="button" data-ap-mode="light" class="${ap.mode === "light" ? "on" : ""}">Light</button>
          <button type="button" data-ap-mode="dark" class="${ap.mode === "dark" ? "on" : ""}">Dark</button>
        </div>
        ${themeActive ? '<div class="ap-note" style="margin-top:8px">A theme is active. Picking a mode switches it off.</div>' : ""}
      </div>
      <div class="ap-sec">
        <div class="ap-label">Accent colour</div>
        <div class="ap-swatches">
          <button type="button" class="ap-sw reset${ap.accent ? "" : " on"}" data-ap-accent="" title="Default" aria-label="Default accent"></button>
          ${swatches}
          <label class="ap-custom" title="Custom colour"><input type="color" id="ap-color" value="${ap.accent || "#8a1c4d"}"></label>
        </div>
      </div>
      <div class="ap-sec">
        <div class="ap-label">Themes</div>
        <div class="ap-themes">${themeCards}</div>
      </div>`;
    if (card) card.scrollTop = keepScroll;
  }

  function apOpenPanel() {
    try {
      apInjectStyles();

      const existing = document.getElementById("ap-overlay");
      if (existing) { existing.remove(); return; }

      const overlay = document.createElement("div");
      overlay.id = "ap-overlay";
      overlay.style.cssText =
        "position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483647;" +
        "display:flex;align-items:center;justify-content:center;" +
        "background:rgba(0,0,0,.35);padding:16px;box-sizing:border-box;";

      overlay.innerHTML = `
        <div class="ap-card" role="dialog" aria-label="Appearance"
             style="width:min(560px,100%);max-height:88vh;overflow-y:auto;box-sizing:border-box;">
          <div class="ap-head"><strong>Appearance</strong>
            <button type="button" class="ap-x" aria-label="Close">×</button></div>
          <div class="ap-body"></div>
        </div>`;

      overlay.addEventListener("click", e => {
        if (e.target === overlay || e.target.closest(".ap-x")) { overlay.remove(); return; }
        const mode = e.target.closest("[data-ap-mode]");
        const acc = e.target.closest("[data-ap-accent]");
        const th = e.target.closest("[data-ap-theme]");
        if (mode) { ap.mode = mode.dataset.apMode; ap.theme = "none"; }
        else if (acc) { ap.accent = acc.dataset.apAccent || null; }
        else if (th) { ap.theme = th.dataset.apTheme; ap.accent = null; }
        else return;
        apSave(); apApply(); apRender();
      });
      // live preview while dragging the colour picker (no re-render so the picker stays open)
      overlay.addEventListener("input", e => {
        if (e.target.id !== "ap-color") return;
        ap.accent = e.target.value; apSave(); apApply();
      });
      overlay.addEventListener("change", e => { if (e.target.id === "ap-color") apRender(); });

      document.documentElement.appendChild(overlay);
      apRender();
    } catch (err) {
      console.error("[Appearance] failed to open:", err);
    }
  }

  /* Finds near-white backgrounds / dark text on any page and tags them,
     so the theme colours them. Pastel and coloured cells (like timetable
     subjects) are left alone. */
  let apSeen = new WeakSet();
  let apTimer = null;

  function apRgb(str) {
    const m = (str || "").match(/[\d.]+/g);
    if (!m || m.length < 3) return null;
    return { r: +m[0], g: +m[1], b: +m[2], a: m.length > 3 ? +m[3] : 1 };
  }
  const apLumOf = c => (0.299 * c.r + 0.587 * c.g + 0.114 * c.b) / 255;

  function apEffectiveBg(el) {
    for (let n = el, i = 0; n && i < 8; n = n.parentElement, i++) {
      const c = apRgb(getComputedStyle(n).backgroundColor);
      if (c && c.a >= 0.5) return c;
    }
    return null; // falls through to the themed page background
  }

  function apProcessDirty() {
    apDirty.forEach((info, el) => {
      if (!el.isConnected) return;
      const rowish = /^(TR|TD|TH)$/.test(el.tagName);
      const targets = rowish
        ? [el, ...(el.tagName === "TR" ? el.querySelectorAll(":scope > td, :scope > th") : [])]
        : [el, ...Array.from(el.querySelectorAll("*")).slice(0, 600)];
      targets.forEach(x => {
        x.classList.remove("ap-lightbg", "ap-darktext", "ap-darklink", "ap-rowsel");
        apSeen.delete(x);
      });
      // a row that just became "selected" and is white -> accent highlight instead of plain panel
      if (rowish && info.state) {
        targets.forEach(x => {
          if (apNearWhite(apRgb(getComputedStyle(x).backgroundColor))) {
            x.classList.add("ap-rowsel");
            apSeen.add(x);
          }
        });
      }
    });
    apDirty.clear();
  }

  new MutationObserver(recs => {
    if (!document.documentElement.classList.contains("ap-pal")) return;
    let any = false;
    for (const r of recs) {
      const t = r.target;
      if (!(t instanceof Element)) continue;
      if (t.closest("#orbit-shell, #orbit-nav, #ap-overlay, #orbit-announcement")) continue;
      if (!t.closest(".main-body")) continue;
      const now = t.getAttribute(r.attributeName) || "";
      const old = r.oldValue || "";
      let state = false;
      if (r.attributeName === "class") {
        const a = apStripAp(old).split(/\s+/), b = apStripAp(now).split(/\s+/);
        if (a.join(" ") === b.join(" ")) continue;          // only our own ap- classes changed
        state = b.some(x => x && !a.includes(x));            // a class was ADDED = selected/hover/active
      } else {
        if (now === old) continue;
        state = /background/i.test(now);
      }
      apDirty.set(t, { state });
      any = true;
    }
    if (any) apSchedule();
  }).observe(document.documentElement, {
    attributes: true, attributeFilter: ["class", "style"], attributeOldValue: true, subtree: true
  });

  const apNearWhite = c => c && c.a >= 0.5 && Math.min(c.r, c.g, c.b) >= 235;

  function apRepaint() {
    const root = document.documentElement;
    if (!root.classList.contains("ap-pal")) {
      document.querySelectorAll(".ap-lightbg, .ap-darktext, .ap-darklink").forEach(e =>
        e.classList.remove("ap-lightbg", "ap-darktext", "ap-darklink"));
      apSeen = new WeakSet();
      return;
    }

    const scope = document.querySelector(".main-body") || document.body;
    scope.querySelectorAll("*").forEach(el => {
      if (apSeen.has(el)) return;
      if (/^(SCRIPT|STYLE|IMG|SVG|PATH|LINK|META|BR|CANVAS|IFRAME)$/i.test(el.tagName)) return;
      if (el.closest("#orbit-shell, #orbit-nav, #ap-overlay, #orbit-announcement, svg, table")) return;   // tables left alone
      apSeen.add(el);
      const cs = getComputedStyle(el);

      if (apNearWhite(apRgb(cs.backgroundColor))) el.classList.add("ap-lightbg");

      const fg = apRgb(cs.color);
      if (fg && apLumOf(fg) < 0.45 && (Math.max(fg.r, fg.g, fg.b) - Math.min(fg.r, fg.g, fg.b)) < 50 && el.textContent.trim()) {
        const eff = apEffectiveBg(el);
        if (!eff || apLumOf(eff) < 0.5) el.classList.add(el.tagName === "A" ? "ap-darklink" : "ap-darktext");
      }
    });
  }

  function apSchedule() {
    clearTimeout(apTimer);
    apTimer = setTimeout(apRepaint, 250);
  }

  function apEnsureMenuItem() {
    const menu = document.querySelector(".orbit-user-menu");
    if (!menu || menu.querySelector(".orbit-user-appearance")) return;
    const b = make("button", "orbit-user-menu-item orbit-user-appearance");
    b.type = "button";
    b.innerHTML = `${AP_ICON}<span>Appearance</span>`;
    b.addEventListener("click", e => {
      e.stopPropagation();
      const u = document.querySelector(".orbit-user");
      if (u) u.classList.remove("open");
      apOpenPanel();
    });
    const logout = menu.querySelector(".orbit-user-logout");
    if (logout) menu.insertBefore(b, logout); else menu.appendChild(b);
  }

  document.addEventListener("keydown", e => {
    if (e.key === "Escape") { const o = document.getElementById("ap-overlay"); if (o) o.remove(); }
  });
  apInjectStyles();
  apApply();
  new MutationObserver(() => { apEnsureMenuItem(); apSchedule(); }).observe(document.documentElement, { childList: true, subtree: true });
  apSchedule();
  apEnsureMenuItem();
  /* ============================ end appearance ============================ */

    /* ======================================================================
     SUBJECT LINKS  (menu item -> panel -> link buttons in the timetable)
     ====================================================================== */
  const SL_KEY = "orbit-sublinks-v1";
  const slHasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;

  function slLoad() {
    const base = { links: [] };
    try { return Object.assign(base, JSON.parse(localStorage.getItem(SL_KEY) || "{}")); }
    catch { return base; }
  }
  let sl = slLoad();
  if (!Array.isArray(sl.links)) sl.links = [];

  function slSave() {
    try { localStorage.setItem(SL_KEY, JSON.stringify(sl)); } catch {}
    if (slHasChrome) { try { chrome.storage.local.set({ [SL_KEY]: sl }); } catch {} }
  }
  if (slHasChrome) {
    try {
      chrome.storage.local.get([SL_KEY], r => {
        if (r && r[SL_KEY] && Array.isArray(r[SL_KEY].links)) { sl = r[SL_KEY]; slApply(); }
      });
    } catch {}
  }

  const slEsc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  function slCleanUrl(u) {
    u = (u || "").trim();
    if (!u) return "";
    if (!/^[a-z][a-z0-9+.-]*:/i.test(u)) u = "https://" + u;
    try {
      const p = new URL(u);
      return (p.protocol === "http:" || p.protocol === "https:") ? p.href : "";
    } catch { return ""; }
  }

  // Only subjects that have a name AND a valid link count as "chosen"
  function slActive() {
    return sl.links
      .map(l => ({ key: (l.name || "").trim().toLowerCase(), url: slCleanUrl(l.url) }))
      .filter(l => l.key && l.url)
      .sort((a, b) => b.key.length - a.key.length);
  }

  function slScopes() {
    const out = [];
    const home = document.getElementById("timetable");
    if (home) out.push(home);
    if (currentKey() === "Timetable") {
      const m = document.querySelector(".main-body-content") || document.querySelector(".main-body");
      if (m) out.push(m);
    }
    return out;
  }

  const SL_SKIP = /^(SCRIPT|STYLE|NOSCRIPT|SVG|PATH|INPUT|SELECT|OPTION|TEXTAREA|BUTTON|IFRAME|CANVAS)$/i;
  const SL_IGNORE = "#orbit-shell, #orbit-nav, #sl-overlay, #ap-overlay, #orbit-announcement, .orbit-sublink";

  function slButton(link) {
    const a = document.createElement("a");
    a.className = "orbit-sublink";
    a.href = link.url;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.title = "Open subject link";
    a.dataset.slKey = link.key;
    a.dataset.slUrl = link.url;
    a.innerHTML = ICONS.link;
    a.addEventListener("click", e => {
      e.preventDefault();
      e.stopPropagation();
      window.open(link.url, "_blank", "noopener,noreferrer");
    });
    return a;
  }

  function slApply() {
    slInjectStyles();
    const active = slActive();

    // remove buttons for subjects that were removed or whose link changed
    document.querySelectorAll(".orbit-sublink").forEach(b => {
      const ok = active.some(l => l.key === b.dataset.slKey && l.url === b.dataset.slUrl);
      if (!ok) b.remove();
    });
    if (!active.length) return;

    slScopes().forEach(scope => {
      scope.querySelectorAll("*").forEach(el => {
        if (SL_SKIP.test(el.tagName) || el.closest(SL_IGNORE)) return;
        const txt = el.textContent.toLowerCase();
        const link = active.find(l => txt.includes(l.key));
        if (!link) return;

        // only the deepest element containing the subject gets the button
        for (const c of el.children) {
          if (c.classList.contains("orbit-sublink")) continue;
          if (c.textContent.toLowerCase().includes(link.key)) return;
        }

        const anchor = el.closest("a");
        if (anchor) {
          const next = anchor.nextElementSibling;
          if (next && next.classList.contains("orbit-sublink")) return;
          anchor.after(slButton(link));
        } else {
          if (el.querySelector(":scope > .orbit-sublink")) return;
          el.appendChild(slButton(link));
        }
      });
    });
  }

  let slTimer = null;
  function slSchedule() { clearTimeout(slTimer); slTimer = setTimeout(slApply, 300); }

  // Short text pieces found in the timetable, offered as quick-add chips
  function slDetect() {
    const seen = new Map();
    const bad = /^(mon|tue|wed|thu|fri|sat|sun|today|tomorrow|period|break|recess|lunch|timetable|no classes|none|room|p\d+|\d+)/i;
    slScopes().forEach(scope => {
      scope.querySelectorAll("*").forEach(el => {
        if (SL_SKIP.test(el.tagName) || el.closest(SL_IGNORE) || el.children.length) return;
        const t = el.textContent.replace(/\s+/g, " ").trim();
        if (t.length < 2 || t.length > 40) return;
        if (/^\d{1,2}[:.]\d{2}/.test(t) || bad.test(t)) return;
        const k = t.toLowerCase();
        if (!seen.has(k)) seen.set(k, t);
      });
    });
    return Array.from(seen.values()).slice(0, 30);
  }

  function slInjectStyles() {
    if (document.getElementById("orbit-sublink-styles")) return;
    const style = document.createElement("style");
    style.id = "orbit-sublink-styles";
    style.textContent = `
      html body a.orbit-sublink {
        display: inline-flex; align-items: center; justify-content: center;
        width: 20px; height: 20px; margin-left: 6px; vertical-align: middle;
        border-radius: 5px; cursor: pointer; text-decoration: none !important;
        color: var(--ap-accent, #8a1c4d) !important;
        background: rgba(0,0,0,.07) !important;
        box-shadow: none !important; padding: 0 !important; line-height: 1;
      }
      html body a.orbit-sublink:hover {
        background: var(--ap-accent, #8a1c4d) !important;
        color: var(--ap-on-accent, #fff) !important;
      }
      a.orbit-sublink svg { width: 13px; height: 13px; display: block; stroke: currentColor !important; }

      #sl-overlay .sl-card {
        background: var(--ap-panel, #fff); color: var(--ap-text, #1a1a1a);
        border: 1px solid var(--ap-border, rgba(0,0,0,.12)); border-radius: var(--ap-radius, 14px);
        box-shadow: var(--ap-shadow, 0 24px 48px -12px rgba(0,0,0,.4));
        font-family: var(--ap-font, system-ui, sans-serif);
      }
      #sl-overlay .sl-head {
        display: flex; justify-content: space-between; align-items: center;
        padding: 16px 20px; border-bottom: 1px solid var(--ap-border, rgba(0,0,0,.1)); font-size: 16px;
      }
      #sl-overlay .sl-x { background: none; border: 0; font-size: 24px; line-height: 1; cursor: pointer; color: var(--ap-muted, #666); }
      #sl-overlay .sl-body { padding: 12px 20px 20px; }
      #sl-overlay .sl-note { font-size: 12px; color: var(--ap-muted, #777); line-height: 1.5; margin: 0 0 12px; }
      #sl-overlay .sl-row { display: grid; grid-template-columns: 1fr 1.6fr auto; gap: 8px; margin-bottom: 8px; }
      #sl-overlay .sl-row input {
        min-width: 0; padding: 8px 10px; font: inherit; font-size: 13px; box-sizing: border-box;
        background: var(--ap-raised, #f4f4f5); color: var(--ap-text, #222);
        border: 1px solid var(--ap-border, rgba(0,0,0,.18)); border-radius: 8px;
      }
      #sl-overlay .sl-del {
        width: 34px; border: 1px solid var(--ap-border, rgba(0,0,0,.18)); border-radius: 8px; cursor: pointer;
        background: transparent; color: var(--ap-muted, #666); font-size: 18px; line-height: 1;
      }
      #sl-overlay .sl-del:hover { color: #dc2626; border-color: #dc2626; }
      #sl-overlay .sl-add {
        padding: 8px 14px; font: inherit; font-size: 13px; cursor: pointer; border: 0; border-radius: 8px;
        background: var(--ap-accent, #8a1c4d); color: var(--ap-on-accent, #fff);
      }
      #sl-overlay .sl-label {
        font-size: 11px; letter-spacing: .12em; text-transform: uppercase; font-weight: 600;
        color: var(--ap-muted, #777); margin: 18px 0 8px;
      }
      #sl-overlay .sl-chips { display: flex; flex-wrap: wrap; gap: 6px; }
      #sl-overlay .sl-chip {
        padding: 5px 10px; font: inherit; font-size: 12px; cursor: pointer; border-radius: 999px;
        background: var(--ap-raised, #f4f4f5); color: var(--ap-text, #222);
        border: 1px solid var(--ap-border, rgba(0,0,0,.15));
      }
      #sl-overlay .sl-chip:hover { border-color: var(--ap-accent, #8a1c4d); }
      #sl-overlay .sl-empty { font-size: 13px; color: var(--ap-muted, #777); margin: 0 0 10px; }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function slRender() {
    const o = document.getElementById("sl-overlay");
    if (!o) return;
    const card = o.querySelector(".sl-card");
    const keep = card ? card.scrollTop : 0;
    const body = o.querySelector(".sl-body");

    const rows = sl.links.map((l, i) => `
      <div class="sl-row">
        <input type="text" data-i="${i}" data-f="name" placeholder="Subject (e.g. Maths)" value="${slEsc(l.name)}">
        <input type="url" data-i="${i}" data-f="url" placeholder="https://..." value="${slEsc(l.url)}">
        <button type="button" class="sl-del" data-i="${i}" aria-label="Remove">×</button>
      </div>`).join("");

    const found = slDetect().filter(n => !sl.links.some(l => (l.name || "").trim().toLowerCase() === n.toLowerCase()));
    const chips = found.length
      ? `<div class="sl-label">Found on this page</div>
         <div class="sl-chips">${found.map(n => `<button type="button" class="sl-chip" data-name="${slEsc(n)}">+ ${slEsc(n)}</button>`).join("")}</div>`
      : "";

    body.innerHTML = `
      <p class="sl-note">Type the subject name as it appears in your timetable and paste its link.
        A link button then appears next to that subject on Home and the Timetable.
        Subjects without a link get no button.</p>
      ${rows || '<p class="sl-empty">No subjects added yet.</p>'}
      <button type="button" class="sl-add">+ Add subject</button>
      ${chips}`;
    if (card) card.scrollTop = keep;
  }

  function slOpenPanel() {
    try {
      slInjectStyles();
      const existing = document.getElementById("sl-overlay");
      if (existing) { existing.remove(); return; }

      const o = document.createElement("div");
      o.id = "sl-overlay";
      o.style.cssText =
        "position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483647;" +
        "display:flex;align-items:center;justify-content:center;" +
        "background:rgba(0,0,0,.35);padding:16px;box-sizing:border-box;";
      o.innerHTML = `
        <div class="sl-card" role="dialog" aria-label="Subject links"
             style="width:min(560px,100%);max-height:88vh;overflow-y:auto;box-sizing:border-box;">
          <div class="sl-head"><strong>Subject links</strong>
            <button type="button" class="sl-x" aria-label="Close">×</button></div>
          <div class="sl-body"></div>
        </div>`;

      o.addEventListener("click", e => {
        if (e.target === o || e.target.closest(".sl-x")) { o.remove(); return; }
        const del = e.target.closest(".sl-del");
        const add = e.target.closest(".sl-add");
        const chip = e.target.closest(".sl-chip");
        if (del) {
          sl.links.splice(+del.dataset.i, 1);
          slSave(); slApply(); slRender();
        } else if (add) {
          sl.links.push({ name: "", url: "" });
          slSave(); slRender();
          const ins = o.querySelectorAll('input[data-f="name"]');
          if (ins.length) ins[ins.length - 1].focus();
        } else if (chip) {
          sl.links.push({ name: chip.dataset.name, url: "" });
          slSave(); slRender();
          const ins = o.querySelectorAll('input[data-f="url"]');
          if (ins.length) ins[ins.length - 1].focus();
        }
      });

      // typing: save + update buttons live (no re-render, so the cursor stays put)
      o.addEventListener("input", e => {
        const t = e.target;
        if (!t.dataset || t.dataset.f === undefined) return;
        const row = sl.links[+t.dataset.i];
        if (!row) return;
        row[t.dataset.f] = t.value;
        slSave(); slSchedule();
      });

      document.documentElement.appendChild(o);
      slRender();
    } catch (err) {
      console.error("[Subject links] failed to open:", err);
    }
  }

  function slEnsureMenuItem() {
    const menu = document.querySelector(".orbit-user-menu");
    if (!menu || menu.querySelector(".orbit-user-sublinks")) return;
    const b = make("button", "orbit-user-menu-item orbit-user-sublinks");
    b.type = "button";
    b.innerHTML = `${ICONS.link}<span>Subject links</span>`;
    b.addEventListener("click", e => {
      e.stopPropagation();
      const u = document.querySelector(".orbit-user");
      if (u) u.classList.remove("open");
      slOpenPanel();
    });
    const appear = menu.querySelector(".orbit-user-appearance");
    const logout = menu.querySelector(".orbit-user-logout");
    if (appear) appear.after(b);
    else if (logout) menu.insertBefore(b, logout);
    else menu.appendChild(b);
  }

  document.addEventListener("keydown", e => {
    if (e.key === "Escape") { const o = document.getElementById("sl-overlay"); if (o) o.remove(); }
  });
  slInjectStyles();
  new MutationObserver(() => { slEnsureMenuItem(); slSchedule(); })
    .observe(document.documentElement, { childList: true, subtree: true });
  slEnsureMenuItem();
  slSchedule();
  /* ============================ end subject links ============================ */

    // Shows "None" when Events & Payments has no real rows
  // (Home card "#tours" + the Events & Payments page)
  function markEmptyEvents() {
    const scopes = [];
    const home = document.getElementById("tours");
    if (home) scopes.push(home);
    if (currentKey() === "Events & Payments") {
      const m = document.querySelector(".main-body-content");
      if (m) scopes.push(m);
    }

    scopes.forEach(scope => {
      const holder = scope.querySelector(".section-body") || scope;
      const existing = holder.querySelector(":scope > .orbit-none");

      // rows that actually contain something (ignores "No data available" style rows)
      const realRows = Array.from(scope.querySelectorAll("tbody tr")).filter(tr => {
        const t = tr.textContent.replace(/\s+/g, " ").trim();
        return t && !/no (data|records|events|tours|payments|items|results)|nothing to (show|display)|^none$/i.test(t);
      });

      if (realRows.length) {
        if (existing) existing.remove();
        return;
      }
      // already has a "None" (ours, or from markEmptySections)
      if (existing || holder.querySelector(":scope > .orbit-empty")) return;

      const p = make("p", "orbit-none", "None");
      p.style.cssText = "margin:12px 16px;color:var(--ap-muted,#777);font-size:14px;";
      holder.appendChild(p);
    });
  }


  function init() {
    injectCoreStyles();
    document.documentElement.classList.toggle("orbit-page-calendar", currentKey() === "Calendar");
    setFavicon();
    injectAnnouncementStyles();
    checkCloudflareAnnouncement();
    createOrbitUI();
    hideOldChrome();
    styleTables();
    unlockScroll();
    updateLayoutVars();
    fixPdfEmbeds();
    if (currentKey() === "Home") transformHome();
    markEmptySections();
    markEmptyEvents();
    if (currentKey() === "Home") pinMainRight();
    document.body.classList.add("orbit-ready");
  }

  setInterval(checkCloudflareAnnouncement, 6000);

    let userScrolled = false;
  ["wheel", "touchstart", "keydown", "mousedown"].forEach(ev =>
    window.addEventListener(ev, () => { userScrolled = true; }, { passive: true, capture: true })
  );

  function scrollMainToRight() {
    if (userScrolled) return;
    const nav = document.getElementById("orbit-nav");
    const header = document.getElementById("orbit-shell");
    const root = document.scrollingElement || document.documentElement;

    const candidates = [root, document.documentElement, document.body, ...document.querySelectorAll("body *")];
    candidates.forEach(el => {
      if (!el || (nav && nav.contains(el)) || (header && header.contains(el))) return;
      if (el.classList && el.classList.contains("orbit-quick-grid")) return; // keep quick cards starting at the left
      if (el.scrollWidth <= el.clientWidth + 5) return;
      const ox = getComputedStyle(el).overflowX;
      const isRoot = el === root || el === document.documentElement || el === document.body;
      if (isRoot || ox === "auto" || ox === "scroll") el.scrollLeft = el.scrollWidth;
    });
    window.scrollTo({ left: document.documentElement.scrollWidth, top: window.scrollY, behavior: "instant" });
  }

  function pinMainRight() {
    let tries = 0;
    const tick = () => {
      scrollMainToRight();
      if (++tries < 20 && !userScrolled) setTimeout(tick, 250); // retries for ~5s while gadgets load
    };
    tick();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, {once:true});
  } else {
    init();
  }

  window.addEventListener("resize", updateLayoutVars);
  window.addEventListener("load", () => { if (currentKey() === "Home") pinMainRight(); });

  let isFixing = false;
  const observer = new MutationObserver(() => {
    if (isFixing) return;
    isFixing = true;

    // Destroy any dynamically created black backdrops
    document.querySelectorAll('.modal-backdrop').forEach(b => b.remove());

    if (!document.querySelector("#orbit-shell")) createOrbitUI();
    hideOldChrome();
    styleTables();
    unlockScroll();
    updateLayoutVars();
    fixPdfEmbeds();
    if (currentKey() === "Home") transformHome();
    markEmptySections();
    markEmptyEvents();

    requestAnimationFrame(() => { isFixing = false; });
  });
  observer.observe(document.documentElement, {childList:true, subtree:true});
})();