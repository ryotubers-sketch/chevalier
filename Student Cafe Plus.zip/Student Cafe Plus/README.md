# Chevalier Student Café • Orbit Style

This Chrome/Edge Manifest V3 extension restyles the existing Chevalier TASS Student Café.

It does not replace TASS, store your password, or send your school information anywhere.
It only changes the page layout in your browser.

## Install on Chrome or Edge

1. Unzip this folder.
2. Open `chrome://extensions` in Chrome or `edge://extensions` in Edge.
3. Turn on **Developer mode**.
4. Choose **Load unpacked**.
5. Select this folder.
6. Open:
   https://chevalier.nsw.tass.cloud/studentcafe/

The extension will activate automatically on the Student Café site.

## Notes

The design is inspired by the clean, card-based approach used by TASS Orbit.
It uses the existing Student Café links and information rather than creating fake school data.

## What's new in this version

**Chevalier branding.** The colour palette now uses the school's own colours —
Marron `#520f2e` and Collage Cream `#f2f2eb` — instead of the placeholder blue.
The header shows the real Chevalier logo (loaded live from
chevalier.nsw.edu.au) instead of a plain "C" badge. If the Student Café's own
security policy ever blocks that external image, the extension automatically
falls back to the plain badge so the layout never breaks.

**Cropping fix, made robust.** TASS nests more than one `.main-body` /
`.main-body-content` element inside each other. The previous fix assumed a
fixed nesting depth in the CSS, which works today but would silently break
(and re-crop the page) if TASS ever changes its markup. This version instead
has the extension script walk the real page structure every time it runs and
tag only the outermost wrapper for the header/sidebar offset, leaving any
nested duplicate wrappers untouched. That's what actually stops content from
being pushed off-screen or clipped, and it keeps working even if TASS's
internal markup shifts slightly.

**Extension name and icon.** The extension is now called "Student Café+" and
uses a maroon monogram icon (`icons/`). We can't pull the real school logo
into a packaged extension icon automatically, so this is a simple maroon "C"
badge in the same style as the in-page fallback mark — swap the PNGs in
`icons/` for the real artwork if you'd like an exact match.

**Empty sections say "None".** Card sections with nothing in them (e.g. an
empty Extra Curricular list) now show "None" instead of a blank card. It
re-checks on every page update, so a section that loads content later isn't
stuck showing "None".

**Casual, time-based greeting.** The hero now reads "hii 👋, `<name>`." in the
morning and shifts to "heyy" / "hey" / "yo" later in the day, instead of the
old "Good morning/afternoon/evening" line. The tagline and the faint logo
watermark have been removed from the hero for a cleaner look.

**Notices button and favicon are best-effort.** The bell now tries a few
different ways to find the notices on the page (an id, then a class match)
before falling back to just navigating to the Notices page — we can't
confirm the exact element TASS uses without access to the live, logged-in
site. The tab favicon is swapped to the maroon logo via the page's own
`<link rel="icon">`, which is subject to the Student Café's security policy
same as the header logo - if it's blocked, the tab keeps its original icon.
